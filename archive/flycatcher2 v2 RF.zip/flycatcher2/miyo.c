#include "miyo.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Random float [0, 1]
static float frand(void)
{
    return rand() / (float)RAND_MAX;
}

// Random float [-1, 1]
static float frand_sym(void)
{
    return frand() * 2.0f - 1.0f;
}

// Activations
static float act_sigmoid(float x)
{
    return 1.0f / (1.0f + expf(-x));
}

static float act_tanh(float x)
{
    return tanhf(x);
}

static float act_relu(float x)
{
    return x > 0.0f ? x : 0.0f;
}

static float act_leaky_relu(float x)
{
    return x > 0.0f ? x : 0.01f * x;
}

// Activation derivatives
static float pd_sigmoid(float y)
{
    return y * (1.0f - y);
}

static float pd_tanh(float y)
{
    return 1.0f - y * y;
}

static float pd_relu(float y)
{
    return y > 0.0f ? 1.0f : 0.0f;
}

static float pd_leaky_relu(float y)
{
    return y > 0.0f ? 1.0f : 0.01f;
}

static float activate(float x, MiyoActivation act)
{
    if(act == MIYO_ACT_SIGMOID) return act_sigmoid(x);
    if(act == MIYO_ACT_TANH) return act_tanh(x);
    if(act == MIYO_ACT_RELU) return act_relu(x);
    if(act == MIYO_ACT_LEAKY_RELU) return act_leaky_relu(x);
    return x;
}

static float pd_activate(float y, MiyoActivation act)
{
    if(act == MIYO_ACT_SIGMOID) return pd_sigmoid(y);
    if(act == MIYO_ACT_TANH) return pd_tanh(y);
    if(act == MIYO_ACT_RELU) return pd_relu(y);
    if(act == MIYO_ACT_LEAKY_RELU) return pd_leaky_relu(y);
    return 1.0f;
}

// Softmax
static void apply_softmax(float* output, int size)
{
    float max_val = output[0];
    for(int i = 1; i < size; i++)
        if(output[i] > max_val) max_val = output[i];
    
    float sum = 0.0f;
    for(int i = 0; i < size; i++)
    {
        output[i] = expf(output[i] - max_val);
        sum = sum + output[i];
    }
    for(int i = 0; i < size; i++)
        output[i] = output[i] / sum;
}

// Weight init
static void init_weights_random(float* w, int count)
{
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * 0.5f;
}

static void init_weights_xavier(float* w, int nin, int nout, int count)
{
    float limit = sqrtf(6.0f / (nin + nout));
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * limit;
}

static void init_weights_he(float* w, int nin, int count)
{
    float limit = sqrtf(6.0f / nin);
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * limit;
}

// Grad clip
static float clip_value(float val, float threshold)
{
    if(threshold <= 0.0f) return val;
    if(val > threshold) return threshold;
    if(val < -threshold) return -threshold;
    return val;
}

MiyoConfig miyo_config_default(void)
{
    MiyoConfig c;
    c.layer_sizes = NULL;
    c.num_layers = 0;
    c.layer_acts = NULL;
    c.learning_rate = 0.01f;
    c.optimizer = MIYO_OPT_SGD;
    c.momentum = 0.9f;
    c.rmsprop_decay = 0.9f;
    c.rmsprop_epsilon = 1e-8f;
    c.l2_lambda = 0.0f;
    c.dropout_rate = 0.0f;
    c.grad_clip = 0.0f;
    c.loss_type = MIYO_LOSS_MSE;
    c.init_type = MIYO_INIT_XAVIER;
    c.lr_schedule = MIYO_LR_CONSTANT;
    c.lr_decay_rate = 0.95f;
    c.lr_step_size = 10;
    c.total_epochs = 100;
    c.early_stop_patience = 0;
    c.early_stop_delta = 0.0001f;
    return c;
}

// Allocate layer
static MiyoLayer layer_alloc(int in_size, int out_size, MiyoActivation act,
                             MiyoWeightInit init, float dropout, MiyoOptimizer opt)
{
    MiyoLayer l;
    l.in_size = in_size;
    l.out_size = out_size;
    l.act = act;
    l.dropout_rate = dropout;
    
    int nw = out_size * in_size;
    
    l.weights = (float*)calloc(nw, sizeof(float));
    l.biases = (float*)calloc(out_size, sizeof(float));
    l.output = (float*)calloc(out_size, sizeof(float));
    l.output_pre_dropout = (float*)calloc(out_size, sizeof(float));
    l.pre_act = (float*)calloc(out_size, sizeof(float));
    l.delta = (float*)calloc(out_size, sizeof(float));
    l.grad_w = (float*)calloc(nw, sizeof(float));
    l.grad_b = (float*)calloc(out_size, sizeof(float));
    
    // Optimizer caches
    if(opt == MIYO_OPT_MOMENTUM || opt == MIYO_OPT_RMSPROP)
    {
        l.cache_w = (float*)calloc(nw, sizeof(float));
        l.cache_b = (float*)calloc(out_size, sizeof(float));
    }
    else
    {
        l.cache_w = NULL;
        l.cache_b = NULL;
    }
    
    // Dropout mask
    if(dropout > 0.0f)
        l.dropout_mask = (int*)malloc(out_size * sizeof(int));
    else
        l.dropout_mask = NULL;
    
    // Initialize weights
    if(init == MIYO_INIT_XAVIER)
        init_weights_xavier(l.weights, in_size, out_size, nw);
    else if(init == MIYO_INIT_HE)
        init_weights_he(l.weights, in_size, nw);
    else
        init_weights_random(l.weights, nw);
    
    return l;
}

// Free layer
static void layer_free(MiyoLayer* l)
{
    free(l->weights);
    free(l->biases);
    free(l->output);
    free(l->output_pre_dropout);
    free(l->pre_act);
    free(l->delta);
    free(l->grad_w);
    free(l->grad_b);
    if(l->cache_w) free(l->cache_w);
    if(l->cache_b) free(l->cache_b);
    if(l->dropout_mask) free(l->dropout_mask);
}

Miyo miyo_build(MiyoConfig cfg)
{
    Miyo m;
    m.nips = cfg.layer_sizes[0];
    m.nops = cfg.layer_sizes[cfg.num_layers - 1];
    m.num_layers = cfg.num_layers - 1;
    m.optimizer = cfg.optimizer;
    m.momentum = cfg.momentum;
    m.rmsprop_decay = cfg.rmsprop_decay;
    m.rmsprop_epsilon = cfg.rmsprop_epsilon;
    m.l2_lambda = cfg.l2_lambda;
    m.grad_clip = cfg.grad_clip;
    m.loss_type = cfg.loss_type;
    m.base_lr = cfg.learning_rate;
    m.training = 1;
    m.batch_count = 0;
    m.batch_loss = 0.0f;
    
    m.layers = (MiyoLayer*)malloc(m.num_layers * sizeof(MiyoLayer));
    
    for(int i = 0; i < m.num_layers; i++)
    {
        int in_size = cfg.layer_sizes[i];
        int out_size = cfg.layer_sizes[i + 1];
        int is_output = (i == m.num_layers - 1);
        
        MiyoActivation act;
        if(cfg.layer_acts != NULL)
            act = cfg.layer_acts[i];
        else
        {
            if(is_output)
                act = (cfg.loss_type == MIYO_LOSS_CROSS_ENTROPY) ? MIYO_ACT_SOFTMAX : MIYO_ACT_SIGMOID;
            else
                act = MIYO_ACT_RELU;
        }
        
        float dropout = is_output ? 0.0f : cfg.dropout_rate;
        
        m.layers[i] = layer_alloc(in_size, out_size, act, cfg.init_type,
                                  dropout, cfg.optimizer);
    }
    
    // Early stopping
    if(cfg.early_stop_patience > 0)
    {
        m.early_stop = (MiyoEarlyStopping*)malloc(sizeof(MiyoEarlyStopping));
        m.early_stop->best_error = 1e9f;
        m.early_stop->patience = cfg.early_stop_patience;
        m.early_stop->wait_count = 0;
        m.early_stop->enabled = 1;
        m.early_stop->min_delta = cfg.early_stop_delta;
    }
    else
        m.early_stop = NULL;
    
    // Learning rate scheduler
    if(cfg.lr_schedule != MIYO_LR_CONSTANT)
    {
        m.lr_sched = (MiyoLRScheduler*)malloc(sizeof(MiyoLRScheduler));
        m.lr_sched->type = cfg.lr_schedule;
        m.lr_sched->initial_lr = cfg.learning_rate;
        m.lr_sched->current_lr = cfg.learning_rate;
        m.lr_sched->step_size = cfg.lr_step_size;
        m.lr_sched->decay_rate = cfg.lr_decay_rate;
        m.lr_sched->total_epochs = cfg.total_epochs;
        m.lr_sched->current_epoch = 0;
    }
    else
        m.lr_sched = NULL;
    
    return m;
}

void miyo_free(Miyo m)
{
    for(int i = 0; i < m.num_layers; i++)
        layer_free(&m.layers[i]);
    free(m.layers);
    if(m.early_stop) free(m.early_stop);
    if(m.lr_sched) free(m.lr_sched);
}

// Dropout forward
static void dropout_forward(MiyoLayer* l, int training)
{
    for(int i = 0; i < l->out_size; i++)
        l->output_pre_dropout[i] = l->output[i];
    
    if(l->dropout_rate <= 0.0f || l->dropout_mask == NULL) return;
    
    if(training)
    {
        float scale = 1.0f / (1.0f - l->dropout_rate);
        for(int i = 0; i < l->out_size; i++)
        {
            l->dropout_mask[i] = (frand() > l->dropout_rate) ? 1 : 0;
            l->output[i] = l->dropout_mask[i] ? l->output[i] * scale : 0.0f;
        }
    }
}

// Layer forward
static void layer_forward(MiyoLayer* l, const float* input, int training)
{
    for(int i = 0; i < l->out_size; i++)
    {
        float sum = l->biases[i];
        for(int j = 0; j < l->in_size; j++)
            sum = sum + input[j] * l->weights[i * l->in_size + j];
        l->pre_act[i] = sum;
    }
    
    if(l->act == MIYO_ACT_SOFTMAX)
    {
        for(int i = 0; i < l->out_size; i++)
            l->output[i] = l->pre_act[i];
        apply_softmax(l->output, l->out_size);
    }
    else
    {
        for(int i = 0; i < l->out_size; i++)
            l->output[i] = activate(l->pre_act[i], l->act);
    }
    
    dropout_forward(l, training);
}

float* miyo_predict(Miyo* m, const float* input)
{
    const float* layer_input = input;
    
    for(int i = 0; i < m->num_layers; i++)
    {
        layer_forward(&m->layers[i], layer_input, m->training);
        layer_input = m->layers[i].output;
    }
    
    return m->layers[m->num_layers - 1].output;
}

// Loss
static float compute_loss(Miyo* m, const float* target)
{
    MiyoLayer* out = &m->layers[m->num_layers - 1];
    float loss = 0.0f;
    
    if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY)
    {
        if(out->act == MIYO_ACT_SOFTMAX)
        {
            // Categorical CE: -sum(t * log(p))
            for(int i = 0; i < out->out_size; i++)
            {
                float p = out->output[i];
                if(p < 1e-7f) p = 1e-7f;
                loss = loss - target[i] * logf(p);
            }
        }
        else if(out->act == MIYO_ACT_SIGMOID)
        {
            // Binary CE: -sum(t*log(p) + (1-t)*log(1-p))
            for(int i = 0; i < out->out_size; i++)
            {
                float y = out->output[i];
                float t = target[i];
                if(y < 1e-7f) y = 1e-7f;
                if(y > 1.0f - 1e-7f) y = 1.0f - 1e-7f;
                loss = loss - (t * logf(y) + (1.0f - t) * logf(1.0f - y));
            }
        }
        else
        {
            // Fallback to MSE for other activations
            for(int i = 0; i < out->out_size; i++)
            {
                float diff = target[i] - out->output[i];
                loss = loss + 0.5f * diff * diff;
            }
        }
    }
    else
    {
        for(int i = 0; i < out->out_size; i++)
        {
            float diff = target[i] - out->output[i];
            loss = loss + 0.5f * diff * diff;
        }
    }
    
    // L2 regularization
    if(m->l2_lambda > 0.0f)
    {
        float l2_sum = 0.0f;
        for(int l = 0; l < m->num_layers; l++)
        {
            int nw = m->layers[l].in_size * m->layers[l].out_size;
            for(int i = 0; i < nw; i++)
                l2_sum = l2_sum + m->layers[l].weights[i] * m->layers[l].weights[i];
        }
        loss = loss + 0.5f * m->l2_lambda * l2_sum;
    }
    
    return loss;
}

// Output delta
static void compute_output_delta(Miyo* m, const float* target)
{
    MiyoLayer* out = &m->layers[m->num_layers - 1];
    
    if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY && out->act == MIYO_ACT_SOFTMAX)
    {
        // Softmax + CE: delta = y - t
        for(int i = 0; i < out->out_size; i++)
            out->delta[i] = out->output[i] - target[i];
    }
    else if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY && out->act == MIYO_ACT_SIGMOID)
    {
        // Sigmoid + BCE: delta = y - t (simplified form)
        for(int i = 0; i < out->out_size; i++)
            out->delta[i] = out->output[i] - target[i];
    }
    else
    {
        // MSE or CE fallback: dL/dy = (y - t) * f'(pre_act)
        for(int i = 0; i < out->out_size; i++)
        {
            float err = out->output[i] - target[i];
            out->delta[i] = err * pd_activate(out->output_pre_dropout[i], out->act);
        }
    }
}

// Backprop
static void backward(Miyo* m, const float* input)
{
    // Propagate deltas backward through hidden layers
    for(int l = m->num_layers - 2; l >= 0; l--)
    {
        MiyoLayer* curr = &m->layers[l];
        MiyoLayer* next = &m->layers[l + 1];
        
        for(int i = 0; i < curr->out_size; i++)
        {
            // Sum weighted gradients from next layer
            float sum = 0.0f;
            for(int j = 0; j < next->out_size; j++)
                sum = sum + next->delta[j] * next->weights[j * next->in_size + i];
            
            // Apply dropout backward (inverted dropout scaling)
            if(curr->dropout_mask && m->training)
            {
                if(!curr->dropout_mask[i])
                {
                    curr->delta[i] = 0.0f;
                    continue;
                }
                sum = sum / (1.0f - curr->dropout_rate);
            }
            
            // Activation derivative (use pre-dropout output)
            float act_grad = pd_activate(curr->output_pre_dropout[i], curr->act);
            curr->delta[i] = sum * act_grad;
        }
    }
    
    // Compute weight and bias gradients
    for(int l = 0; l < m->num_layers; l++)
    {
        MiyoLayer* layer = &m->layers[l];
        const float* layer_input = (l == 0) ? input : m->layers[l - 1].output;
        
        for(int i = 0; i < layer->out_size; i++)
        {
            // Weight gradients
            for(int j = 0; j < layer->in_size; j++)
            {
                float grad = layer->delta[i] * layer_input[j];
                
                // L2 regularization gradient
                if(m->l2_lambda > 0.0f)
                    grad = grad + m->l2_lambda * layer->weights[i * layer->in_size + j];
                
                grad = clip_value(grad, m->grad_clip);
                layer->grad_w[i * layer->in_size + j] = layer->grad_w[i * layer->in_size + j] + grad;
            }
            
            // Bias gradient
            float bias_grad = clip_value(layer->delta[i], m->grad_clip);
            layer->grad_b[i] = layer->grad_b[i] + bias_grad;
        }
    }
}

// Apply gradients with optimizer
static void apply_gradients(Miyo* m, float lr, int batch_size)
{
    float scale = 1.0f / batch_size;

    for(int l = 0; l < m->num_layers; l++)
    {
        MiyoLayer* layer = &m->layers[l];
        int nw = layer->in_size * layer->out_size;

        if(m->optimizer == MIYO_OPT_SGD)
        {
            for(int i = 0; i < nw; i++)
                layer->weights[i] = layer->weights[i] - lr * layer->grad_w[i] * scale;
            for(int i = 0; i < layer->out_size; i++)
                layer->biases[i] = layer->biases[i] - lr * layer->grad_b[i] * scale;
        }
        else if(m->optimizer == MIYO_OPT_MOMENTUM)
        {
            for(int i = 0; i < nw; i++)
            {
                layer->cache_w[i] = m->momentum * layer->cache_w[i] + layer->grad_w[i] * scale;
                layer->weights[i] = layer->weights[i] - lr * layer->cache_w[i];
            }
            for(int i = 0; i < layer->out_size; i++)
            {
                layer->cache_b[i] = m->momentum * layer->cache_b[i] + layer->grad_b[i] * scale;
                layer->biases[i] = layer->biases[i] - lr * layer->cache_b[i];
            }
        }
        else if(m->optimizer == MIYO_OPT_RMSPROP)
        {
            float decay = m->rmsprop_decay;
            float eps = (m->rmsprop_epsilon > 0.0f) ? m->rmsprop_epsilon : 1e-8f;

            for(int i = 0; i < nw; i++)
            {
                float g = layer->grad_w[i] * scale;
                layer->cache_w[i] = decay * layer->cache_w[i] + (1.0f - decay) * g * g;
                layer->weights[i] = layer->weights[i] - lr * g / (sqrtf(layer->cache_w[i]) + eps);
            }
            for(int i = 0; i < layer->out_size; i++)
            {
                float g = layer->grad_b[i] * scale;
                layer->cache_b[i] = decay * layer->cache_b[i] + (1.0f - decay) * g * g;
                layer->biases[i] = layer->biases[i] - lr * g / (sqrtf(layer->cache_b[i]) + eps);
            }
        }

        // Clear gradients
        for(int i = 0; i < nw; i++) layer->grad_w[i] = 0.0f;
        for(int i = 0; i < layer->out_size; i++) layer->grad_b[i] = 0.0f;
    }
}

float miyo_train(Miyo* m, const float* input, const float* target, float lr)
{
    miyo_predict(m, input);
    float loss = compute_loss(m, target);
    compute_output_delta(m, target);
    backward(m, input);
    apply_gradients(m, lr, 1);
    return loss;
}

void miyo_batch_accumulate(Miyo* m, const float* input, const float* target)
{
    miyo_predict(m, input);
    m->batch_loss = m->batch_loss + compute_loss(m, target);
    compute_output_delta(m, target);
    backward(m, input);
    m->batch_count++;
}

float miyo_batch_update(Miyo* m, float lr)
{
    if(m->batch_count == 0) return 0.0f;
    
    apply_gradients(m, lr, m->batch_count);
    float avg_loss = m->batch_loss / m->batch_count;
    
    m->batch_count = 0;
    m->batch_loss = 0.0f;
    
    return avg_loss;
}

void miyo_epoch_start(Miyo* m)
{
    if(m->lr_sched == NULL) return;
    
    MiyoLRScheduler* s = m->lr_sched;
    int epoch = s->current_epoch;
    
    if(s->type == MIYO_LR_STEP_DECAY)
    {
        if(s->step_size <= 0) { s->current_lr = s->initial_lr; return; }
        int steps = epoch / s->step_size;
        s->current_lr = s->initial_lr * powf(s->decay_rate, (float)steps);
    }
    else if(s->type == MIYO_LR_EXPONENTIAL)
    {
        s->current_lr = s->initial_lr * powf(s->decay_rate, (float)epoch);
    }
    else if(s->type == MIYO_LR_COSINE)
    {
        if(s->total_epochs <= 0) { s->current_lr = s->initial_lr; return; }
        float pi = 3.14159265359f;
        float progress = (float)epoch / (float)s->total_epochs;
        if(progress > 1.0f) progress = 1.0f;
        s->current_lr = s->initial_lr * 0.5f * (1.0f + cosf(pi * progress));
    }
}

void miyo_epoch_end(Miyo* m)
{
    if(m->lr_sched)
        m->lr_sched->current_epoch++;
}

float miyo_get_lr(Miyo* m)
{
    if(m->lr_sched)
        return m->lr_sched->current_lr;
    return m->base_lr;
}

int miyo_early_stop_check(Miyo* m, float error)
{
    if(m->early_stop == NULL || !m->early_stop->enabled) return 0;
    
    MiyoEarlyStopping* es = m->early_stop;
    
    if(error < es->best_error - es->min_delta)
    {
        es->best_error = error;
        es->wait_count = 0;
        return 0;
    }
    
    es->wait_count++;
    if(es->wait_count >= es->patience) return 1;
    return 0;
}

void miyo_set_training(Miyo* m, int training)
{
    m->training = training;
}

// Save network
void miyo_save(Miyo m, const char* path)
{
    FILE* f = fopen(path, "w");
    if(f == NULL) return;

    // Header
    fprintf(f, "%d\n", m.num_layers + 1);
    fprintf(f, "%d ", m.nips);
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%d ", m.layers[i].out_size);
    fprintf(f, "\n");

    // Activations
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%d ", m.layers[i].act);
    fprintf(f, "\n");

    // Dropout rates
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%.9g ", (double)m.layers[i].dropout_rate);
    fprintf(f, "\n");

    // Network config (more precision to keep tiny epsilons)
    fprintf(f, "%d %.9g %.9g %.9g %.9g %.9g %d\n",
            m.optimizer, (double)m.momentum, (double)m.rmsprop_decay,
            (double)m.rmsprop_epsilon, (double)m.l2_lambda,
            (double)m.grad_clip, m.loss_type);
    fprintf(f, "%.9g\n", (double)m.base_lr);

    // LR scheduler state
    int has_lr_sched = (m.lr_sched != NULL) ? 1 : 0;
    fprintf(f, "%d\n", has_lr_sched);
    if(has_lr_sched)
    {
        fprintf(f, "%d %.9g %.9g %d %.9g %d %d\n",
                m.lr_sched->type, (double)m.lr_sched->initial_lr,
                (double)m.lr_sched->current_lr, m.lr_sched->step_size,
                (double)m.lr_sched->decay_rate, m.lr_sched->total_epochs,
                m.lr_sched->current_epoch);
    }

    // Early stopping state
    int has_early_stop = (m.early_stop != NULL) ? 1 : 0;
    fprintf(f, "%d\n", has_early_stop);
    if(has_early_stop)
    {
        fprintf(f, "%.9g %d %d %d %.9g\n",
                (double)m.early_stop->best_error, m.early_stop->patience,
                m.early_stop->wait_count, m.early_stop->enabled,
                (double)m.early_stop->min_delta);
    }

    // Weights and biases
    for(int l = 0; l < m.num_layers; l++)
    {
        MiyoLayer* layer = &m.layers[l];
        int nw = layer->in_size * layer->out_size;

        for(int i = 0; i < nw; i++)
            fprintf(f, "%.9g\n", (double)layer->weights[i]);
        for(int i = 0; i < layer->out_size; i++)
            fprintf(f, "%.9g\n", (double)layer->biases[i]);
    }

    // Optimizer caches
    if(m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP)
    {
        for(int l = 0; l < m.num_layers; l++)
        {
            MiyoLayer* layer = &m.layers[l];
            int nw = layer->in_size * layer->out_size;

            for(int i = 0; i < nw; i++)
                fprintf(f, "%.9g\n", (double)layer->cache_w[i]);
            for(int i = 0; i < layer->out_size; i++)
                fprintf(f, "%.9g\n", (double)layer->cache_b[i]);
        }
    }

    fclose(f);
}

// Load network
Miyo miyo_load(const char* path)
{
    Miyo m;
    memset(&m, 0, sizeof(Miyo));

    FILE* f = fopen(path, "r");
    if(f == NULL)
    {
        fprintf(stderr, "Error: Could not open file '%s'\n", path);
        return m;
    }

    int total_layers;
    if(fscanf(f, "%d\n", &total_layers) != 1 || total_layers < 2)
    {
        fprintf(stderr, "Error: Invalid file format in '%s'\n", path);
        fclose(f);
        return m;
    }

    int* sizes = (int*)malloc(total_layers * sizeof(int));
    for(int i = 0; i < total_layers; i++)
    {
        if(fscanf(f, "%d ", &sizes[i]) != 1)
        {
            fprintf(stderr, "Error: Failed to read layer sizes\n");
            free(sizes);
            fclose(f);
            return m;
        }
    }

    MiyoActivation* acts = (MiyoActivation*)malloc((total_layers - 1) * sizeof(MiyoActivation));
    for(int i = 0; i < total_layers - 1; i++)
    {
        int a;
        if(fscanf(f, "%d ", &a) != 1)
        {
            fprintf(stderr, "Error: Failed to read activations\n");
            free(sizes);
            free(acts);
            fclose(f);
            return m;
        }
        acts[i] = (MiyoActivation)a;
    }

    // Dropout rates
    float* dropouts = (float*)malloc((total_layers - 1) * sizeof(float));
    for(int i = 0; i < total_layers - 1; i++)
    {
        if(fscanf(f, "%f ", &dropouts[i]) != 1)
        {
            fprintf(stderr, "Error: Failed to read dropout rates\n");
            free(sizes);
            free(acts);
            free(dropouts);
            fclose(f);
            return m;
        }
    }

    // Network config
    int optimizer_int, loss_int;
    float momentum, rmsprop_decay, rmsprop_epsilon, l2_lambda, grad_clip, base_lr;
    if(fscanf(f, "%d %f %f %f %f %f %d\n",
              &optimizer_int, &momentum, &rmsprop_decay,
              &rmsprop_epsilon, &l2_lambda, &grad_clip, &loss_int) != 7)
    {
        fprintf(stderr, "Error: Failed to read network config\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }
    if(fscanf(f, "%f\n", &base_lr) != 1)
    {
        fprintf(stderr, "Error: Failed to read base_lr\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }

    // Ensure epsilon is usable (avoid 0 -> NaN in RMSProp)
    if(rmsprop_epsilon <= 0.0f) rmsprop_epsilon = 1e-8f;

    // LR scheduler
    int has_lr_sched;
    MiyoLRScheduler* lr_sched = NULL;
    if(fscanf(f, "%d\n", &has_lr_sched) != 1)
    {
        fprintf(stderr, "Error: Failed to read lr_sched flag\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }
    if(has_lr_sched)
    {
        lr_sched = (MiyoLRScheduler*)malloc(sizeof(MiyoLRScheduler));
        int sched_type;
        if(fscanf(f, "%d %f %f %d %f %d %d\n",
                  &sched_type, &lr_sched->initial_lr, &lr_sched->current_lr,
                  &lr_sched->step_size, &lr_sched->decay_rate,
                  &lr_sched->total_epochs, &lr_sched->current_epoch) != 7)
        {
            fprintf(stderr, "Error: Failed to read lr_sched\n");
            free(sizes);
            free(acts);
            free(dropouts);
            free(lr_sched);
            fclose(f);
            return m;
        }
        lr_sched->type = (MiyoLRSchedule)sched_type;
    }

    // Early stopping
    int has_early_stop;
    MiyoEarlyStopping* early_stop = NULL;
    if(fscanf(f, "%d\n", &has_early_stop) != 1)
    {
        fprintf(stderr, "Error: Failed to read early_stop flag\n");
        free(sizes);
        free(acts);
        free(dropouts);
        if(lr_sched) free(lr_sched);
        fclose(f);
        return m;
    }
    if(has_early_stop)
    {
        early_stop = (MiyoEarlyStopping*)malloc(sizeof(MiyoEarlyStopping));
        if(fscanf(f, "%f %d %d %d %f\n",
                  &early_stop->best_error, &early_stop->patience,
                  &early_stop->wait_count, &early_stop->enabled,
                  &early_stop->min_delta) != 5)
        {
            fprintf(stderr, "Error: Failed to read early_stop\n");
            free(sizes);
            free(acts);
            free(dropouts);
            if(lr_sched) free(lr_sched);
            free(early_stop);
            fclose(f);
            return m;
        }
    }

    // Build network manually to preserve loaded config
    m.nips = sizes[0];
    m.nops = sizes[total_layers - 1];
    m.num_layers = total_layers - 1;
    m.optimizer = (MiyoOptimizer)optimizer_int;
    m.momentum = momentum;
    m.rmsprop_decay = rmsprop_decay;
    m.rmsprop_epsilon = rmsprop_epsilon;
    m.l2_lambda = l2_lambda;
    m.grad_clip = grad_clip;
    m.loss_type = (MiyoLoss)loss_int;
    m.base_lr = base_lr;
    m.training = 0;
    m.batch_count = 0;
    m.batch_loss = 0.0f;
    m.lr_sched = lr_sched;
    m.early_stop = early_stop;

    // Allocate layers
    m.layers = (MiyoLayer*)malloc(m.num_layers * sizeof(MiyoLayer));
    for(int i = 0; i < m.num_layers; i++)
    {
        MiyoLayer* l = &m.layers[i];
        l->in_size = sizes[i];
        l->out_size = sizes[i + 1];
        l->act = acts[i];
        l->dropout_rate = dropouts[i];

        int nw = l->out_size * l->in_size;
        l->weights = (float*)calloc(nw, sizeof(float));
        l->biases = (float*)calloc(l->out_size, sizeof(float));
        l->output = (float*)calloc(l->out_size, sizeof(float));
        l->output_pre_dropout = (float*)calloc(l->out_size, sizeof(float));
        l->pre_act = (float*)calloc(l->out_size, sizeof(float));
        l->delta = (float*)calloc(l->out_size, sizeof(float));
        l->grad_w = (float*)calloc(nw, sizeof(float));
        l->grad_b = (float*)calloc(l->out_size, sizeof(float));

        if(m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP)
        {
            l->cache_w = (float*)calloc(nw, sizeof(float));
            l->cache_b = (float*)calloc(l->out_size, sizeof(float));
        }
        else
        {
            l->cache_w = NULL;
            l->cache_b = NULL;
        }

        if(l->dropout_rate > 0.0f)
            l->dropout_mask = (int*)malloc(l->out_size * sizeof(int));
        else
            l->dropout_mask = NULL;
    }

    // Load weights and biases
    int load_ok = 1;
    for(int l = 0; l < m.num_layers && load_ok; l++)
    {
        MiyoLayer* layer = &m.layers[l];
        int nw = layer->in_size * layer->out_size;

        for(int i = 0; i < nw && load_ok; i++)
        {
            if(fscanf(f, "%f\n", &layer->weights[i]) != 1)
            {
                fprintf(stderr, "Error: Failed to read weight %d in layer %d\n", i, l);
                load_ok = 0;
            }
        }
        for(int i = 0; i < layer->out_size && load_ok; i++)
        {
            if(fscanf(f, "%f\n", &layer->biases[i]) != 1)
            {
                fprintf(stderr, "Error: Failed to read bias %d in layer %d\n", i, l);
                load_ok = 0;
            }
        }
    }

    // Load optimizer caches
    if(load_ok && (m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP))
    {
        for(int l = 0; l < m.num_layers && load_ok; l++)
        {
            MiyoLayer* layer = &m.layers[l];
            int nw = layer->in_size * layer->out_size;

            for(int i = 0; i < nw && load_ok; i++)
            {
                if(fscanf(f, "%f\n", &layer->cache_w[i]) != 1)
                {
                    fprintf(stderr, "Error: Failed to read cache_w %d in layer %d\n", i, l);
                    load_ok = 0;
                }
            }
            for(int i = 0; i < layer->out_size && load_ok; i++)
            {
                if(fscanf(f, "%f\n", &layer->cache_b[i]) != 1)
                {
                    fprintf(stderr, "Error: Failed to read cache_b %d in layer %d\n", i, l);
                    load_ok = 0;
                }
            }
        }
    }

    free(sizes);
    free(acts);
    free(dropouts);
    fclose(f);

    if(!load_ok)
    {
        miyo_free(m);
        memset(&m, 0, sizeof(Miyo));
    }

    return m;
}

void miyo_print(const float* arr, int size)
{
    for(int i = 0; i < size; i++)
        printf("%f ", (double)arr[i]);
    printf("\n");
}

// -----------------------------
// Random Forest (interval + missingness + quality)
// -----------------------------
// MiyoRFNode, MiyoRFTree, MiyoForest structs are defined in miyo.h

typedef struct
{
    int valid;
    int feature;
    float threshold;
    int split_type;
    int missing_go_left;
    float best_gini;
    float left_weight;
    float right_weight;
}
RFBestSplit;

static unsigned int rf_rand_u(MiyoForest* f)
{
    f->rng = f->rng * 1664525u + 1013904223u;
    return f->rng;
}

static float rf_rand_f(MiyoForest* f)
{
    unsigned int r = rf_rand_u(f);
    return (float)(r & 0x00FFFFFFu) / 16777216.0f;
}

static int rf_rand_int(MiyoForest* f, int max_val)
{
    if(max_val <= 1) return 0;
    return (int)(rf_rand_u(f) % (unsigned int)max_val);
}

static float rf_clampf(float v, float lo, float hi)
{
    if(v < lo) return lo;
    if(v > hi) return hi;
    return v;
}

static int rf_is_missing(MiyoRFData* data, int row, int feature)
{
    if(data->missing == NULL) return 0;
    return data->missing[row * data->cols + feature] ? 1 : 0;
}

static int rf_has_interval(MiyoRFData* data)
{
    return (data->x_min != NULL && data->x_max != NULL);
}

static float rf_get_value(MiyoRFData* data, int row, int feature)
{
    return data->x[row * data->cols + feature];
}

static float rf_get_min(MiyoRFData* data, int row, int feature)
{
    return data->x_min[row * data->cols + feature];
}

static float rf_get_max(MiyoRFData* data, int row, int feature)
{
    return data->x_max[row * data->cols + feature];
}

static float rf_get_width(MiyoRFData* data, int row, int feature)
{
    float a = rf_get_min(data, row, feature);
    float b = rf_get_max(data, row, feature);
    float min_v = (a < b) ? a : b;
    float max_v = (a < b) ? b : a;
    return max_v - min_v;
}

static int rf_interval_go_left(MiyoForest* f, MiyoRFData* data, int row, int feature, float threshold)
{
    if(!rf_has_interval(data) || !f->cfg.interval_split)
    {
        float v = rf_get_value(data, row, feature);
        return (v <= threshold) ? 1 : 0;
    }
    float min_v = rf_get_min(data, row, feature);
    float max_v = rf_get_max(data, row, feature);
    float a = (min_v < max_v) ? min_v : max_v;
    float b = (min_v < max_v) ? max_v : min_v;
    if(b <= threshold) return 1;
    if(a > threshold) return 0;
    float width = b - a;
    float frac = 0.5f;
    if(width > 1e-8f)
        frac = (threshold - a) / width;
    return (frac >= 0.5f) ? 1 : 0;
}

static float rf_row_quality(MiyoForest* f, MiyoRFData* data, int row)
{
    if(data->quality == NULL) return 1.0f;
    float sum = 0.0f;
    for(int j = 0; j < data->cols; j++)
        sum = sum + (float)data->quality[row * data->cols + j];
    float norm = sum / (3.0f * (float)data->cols);
    if(norm < 0.0f) norm = 0.0f;
    if(norm > 1.0f) norm = 1.0f;
    if(f->cfg.quality_exp == 1.0f) return norm;
    return powf(norm, f->cfg.quality_exp);
}

static float rf_gini_from_counts(float* counts, int classes, float weight_sum)
{
    if(weight_sum <= 0.0f) return 0.0f;
    float g = 1.0f;
    for(int k = 0; k < classes; k++)
    {
        float p = counts[k] / weight_sum;
        g = g - p * p;
    }
    return g;
}

static void rf_tree_init(MiyoRFTree* t)
{
    t->nodes = NULL;
    t->node_count = 0;
    t->node_capacity = 0;
}

static int rf_tree_add_node(MiyoRFTree* t)
{
    if(t->node_count == t->node_capacity)
    {
        int new_cap = (t->node_capacity == 0) ? 64 : t->node_capacity * 2;
        t->nodes = (MiyoRFNode*)realloc(t->nodes, new_cap * sizeof(MiyoRFNode));
        t->node_capacity = new_cap;
    }
    int idx = t->node_count++;
    memset(&t->nodes[idx], 0, sizeof(MiyoRFNode));
    t->nodes[idx].left = -1;
    t->nodes[idx].right = -1;
    t->nodes[idx].class_counts = NULL;
    return idx;
}

static void rf_tree_free(MiyoRFTree* t)
{
    for(int i = 0; i < t->node_count; i++)
    {
        if(t->nodes[i].class_counts)
            free(t->nodes[i].class_counts);
    }
    if(t->nodes) free(t->nodes);
    t->nodes = NULL;
    t->node_count = 0;
    t->node_capacity = 0;
}

static int rf_is_pure(MiyoRFData* data, int* rows, int n)
{
    if(n <= 1) return 1;
    int y0 = data->y[rows[0]];
    for(int i = 1; i < n; i++)
        if(data->y[rows[i]] != y0) return 0;
    return 1;
}

static void rf_fill_class_counts(MiyoForest* f, MiyoRFData* data, int* rows, int n, float* counts)
{
    for(int k = 0; k < data->classes; k++) counts[k] = 0.0f;
    for(int i = 0; i < n; i++)
    {
        int row = rows[i];
        int cls = data->y[row];
        float w = rf_row_quality(f, data, row);
        counts[cls] = counts[cls] + w;
    }
}

static float rf_interval_weight_penalty(MiyoForest* f, float width)
{
    if(f->cfg.interval_penalty <= 0.0f) return 1.0f;
    return 1.0f / (1.0f + f->cfg.interval_penalty * width);
}

static float rf_eval_split(MiyoForest* f, MiyoRFData* data, int* rows, int n,
                           int feature, float threshold, int split_type, int missing_go_left,
                           float* left_counts, float* right_counts,
                           float* out_left_w, float* out_right_w)
{
    for(int k = 0; k < data->classes; k++)
    {
        left_counts[k] = 0.0f;
        right_counts[k] = 0.0f;
    }
    float left_w = 0.0f;
    float right_w = 0.0f;

    int has_interval = rf_has_interval(data);

    for(int i = 0; i < n; i++)
    {
        int row = rows[i];
        int cls = data->y[row];
        int missing = rf_is_missing(data, row, feature);

        if(split_type == MIYO_RF_SPLIT_MISSING)
        {
            float w = rf_row_quality(f, data, row);
            if(missing)
            {
                if(missing_go_left)
                {
                    left_counts[cls] = left_counts[cls] + w;
                    left_w = left_w + w;
                }
                else
                {
                    right_counts[cls] = right_counts[cls] + w;
                    right_w = right_w + w;
                }
            }
            else
            {
                if(missing_go_left)
                {
                    right_counts[cls] = right_counts[cls] + w;
                    right_w = right_w + w;
                }
                else
                {
                    left_counts[cls] = left_counts[cls] + w;
                    left_w = left_w + w;
                }
            }
            continue;
        }

        if(missing)
        {
            float w = rf_row_quality(f, data, row);
            if(missing_go_left)
            {
                left_counts[cls] = left_counts[cls] + w;
                left_w = left_w + w;
            }
            else
            {
                right_counts[cls] = right_counts[cls] + w;
                right_w = right_w + w;
            }
            continue;
        }

        if(split_type == MIYO_RF_SPLIT_WIDTH)
        {
            float width = has_interval ? rf_get_width(data, row, feature) : 0.0f;
            float w = rf_row_quality(f, data, row);
            w = w * rf_interval_weight_penalty(f, width);
            if(width <= threshold)
            {
                left_counts[cls] = left_counts[cls] + w;
                left_w = left_w + w;
            }
            else
            {
                right_counts[cls] = right_counts[cls] + w;
                right_w = right_w + w;
            }
            continue;
        }

        {
            float w = rf_row_quality(f, data, row);
            if(has_interval && f->cfg.interval_split)
            {
                float width = rf_get_width(data, row, feature);
                w = w * rf_interval_weight_penalty(f, width);
            }

            if(rf_interval_go_left(f, data, row, feature, threshold))
            {
                left_counts[cls] = left_counts[cls] + w;
                left_w = left_w + w;
            }
            else
            {
                right_counts[cls] = right_counts[cls] + w;
                right_w = right_w + w;
            }
        }
    }

    if(out_left_w) *out_left_w = left_w;
    if(out_right_w) *out_right_w = right_w;
    if(left_w <= 0.0f || right_w <= 0.0f) return 1e9f;
    float g_left = rf_gini_from_counts(left_counts, data->classes, left_w);
    float g_right = rf_gini_from_counts(right_counts, data->classes, right_w);
    return (left_w * g_left + right_w * g_right) / (left_w + right_w);
}

static RFBestSplit rf_find_best_split(MiyoForest* f, MiyoRFData* data, int* rows, int n)
{
    RFBestSplit best;
    best.valid = 0;
    best.best_gini = 1e9f;
    best.left_weight = 0.0f;
    best.right_weight = 0.0f;

    int cols = data->cols;
    int mtry = f->cfg.max_features;
    if(mtry <= 0)
    {
        mtry = (int)(sqrtf((float)cols) + 0.5f);
        if(mtry < 1) mtry = 1;
    }
    if(mtry > cols) mtry = cols;

    int* feat = (int*)malloc(cols * sizeof(int));
    for(int i = 0; i < cols; i++) feat[i] = i;
    for(int i = 0; i < mtry; i++)
    {
        int j = i + rf_rand_int(f, cols - i);
        int tmp = feat[i]; feat[i] = feat[j]; feat[j] = tmp;
    }

    float* left_counts = (float*)malloc(data->classes * sizeof(float));
    float* right_counts = (float*)malloc(data->classes * sizeof(float));

    int has_interval = rf_has_interval(data);

    for(int fi = 0; fi < mtry; fi++)
    {
        int feature = feat[fi];

        if(data->missing != NULL)
        {
            for(int mg = 0; mg < 2; mg++)
            {
                float lw = 0.0f, rw = 0.0f;
                float g = rf_eval_split(f, data, rows, n, feature, 0.0f,
                                        MIYO_RF_SPLIT_MISSING, mg, left_counts, right_counts, &lw, &rw);
                if(g < best.best_gini)
                {
                    best.valid = 1;
                    best.best_gini = g;
                    best.feature = feature;
                    best.threshold = 0.0f;
                    best.split_type = MIYO_RF_SPLIT_MISSING;
                    best.missing_go_left = mg;
                    best.left_weight = lw;
                    best.right_weight = rw;
                }
            }
        }

        int candidates = f->cfg.split_candidates;
        if(candidates < 1) candidates = 1;
        for(int c = 0; c < candidates; c++)
        {
            int row = rows[rf_rand_int(f, n)];
            if(rf_is_missing(data, row, feature))
                continue;
            float thr = rf_get_value(data, row, feature);

            for(int mg = 0; mg < 2; mg++)
            {
                float lw = 0.0f, rw = 0.0f;
                float g = rf_eval_split(f, data, rows, n, feature, thr,
                                        MIYO_RF_SPLIT_VALUE, mg, left_counts, right_counts, &lw, &rw);
                if(g < best.best_gini)
                {
                    best.valid = 1;
                    best.best_gini = g;
                    best.feature = feature;
                    best.threshold = thr;
                    best.split_type = MIYO_RF_SPLIT_VALUE;
                    best.missing_go_left = mg;
                    best.left_weight = lw;
                    best.right_weight = rw;
                }
            }
        }

        if(has_interval)
        {
            int candidates_w = f->cfg.split_candidates;
            if(candidates_w < 1) candidates_w = 1;
            for(int c = 0; c < candidates_w; c++)
            {
                int row = rows[rf_rand_int(f, n)];
                if(rf_is_missing(data, row, feature))
                    continue;
                float thr = rf_get_width(data, row, feature);
                for(int mg = 0; mg < 2; mg++)
                {
                    float lw = 0.0f, rw = 0.0f;
                    float g = rf_eval_split(f, data, rows, n, feature, thr,
                                            MIYO_RF_SPLIT_WIDTH, mg, left_counts, right_counts, &lw, &rw);
                    if(g < best.best_gini)
                    {
                        best.valid = 1;
                        best.best_gini = g;
                        best.feature = feature;
                        best.threshold = thr;
                        best.split_type = MIYO_RF_SPLIT_WIDTH;
                        best.missing_go_left = mg;
                        best.left_weight = lw;
                        best.right_weight = rw;
                    }
                }
            }
        }
    }

    free(left_counts);
    free(right_counts);
    free(feat);
    return best;
}

static int rf_partition_rows(MiyoForest* f, MiyoRFData* data, int* rows, int n,
                             int feature, float threshold, int split_type, int missing_go_left,
                             int* left_rows, int* right_rows, int* out_left_n, int* out_right_n)
{
    int left_n = 0;
    int right_n = 0;
    for(int i = 0; i < n; i++)
    {
        int row = rows[i];
        int missing = rf_is_missing(data, row, feature);

        if(split_type == MIYO_RF_SPLIT_MISSING)
        {
            if(missing)
            {
                if(missing_go_left) left_rows[left_n++] = row;
                else right_rows[right_n++] = row;
            }
            else
            {
                if(missing_go_left) right_rows[right_n++] = row;
                else left_rows[left_n++] = row;
            }
            continue;
        }

        if(missing)
        {
            if(missing_go_left) left_rows[left_n++] = row;
            else right_rows[right_n++] = row;
            continue;
        }

        if(split_type == MIYO_RF_SPLIT_WIDTH)
        {
            float width = rf_has_interval(data) ? rf_get_width(data, row, feature) : 0.0f;
            if(width <= threshold) left_rows[left_n++] = row;
            else right_rows[right_n++] = row;
            continue;
        }

        if(rf_interval_go_left(f, data, row, feature, threshold))
            left_rows[left_n++] = row;
        else
            right_rows[right_n++] = row;
    }

    *out_left_n = left_n;
    *out_right_n = right_n;
    if(left_n == 0 || right_n == 0) return 0;
    return 1;
}

static int rf_build_node(MiyoForest* f, MiyoRFData* data, MiyoRFTree* t,
                         int* rows, int n, int depth)
{
    int idx = rf_tree_add_node(t);
    MiyoRFNode* node = &t->nodes[idx];

    if(depth >= f->cfg.max_depth || n < f->cfg.min_samples_split || rf_is_pure(data, rows, n))
    {
        node->is_leaf = 1;
        node->class_counts = (float*)malloc(data->classes * sizeof(float));
        rf_fill_class_counts(f, data, rows, n, node->class_counts);
        return idx;
    }

    RFBestSplit best = rf_find_best_split(f, data, rows, n);
    if(!best.valid || best.left_weight <= 0.0f || best.right_weight <= 0.0f)
    {
        node->is_leaf = 1;
        node->class_counts = (float*)malloc(data->classes * sizeof(float));
        rf_fill_class_counts(f, data, rows, n, node->class_counts);
        return idx;
    }

    int* left_rows = (int*)malloc(n * sizeof(int));
    int* right_rows = (int*)malloc(n * sizeof(int));
    int left_n = 0, right_n = 0;
    int ok = rf_partition_rows(f, data, rows, n, best.feature, best.threshold,
                               best.split_type, best.missing_go_left,
                               left_rows, right_rows, &left_n, &right_n);
    if(!ok)
    {
        free(left_rows);
        free(right_rows);
        node->is_leaf = 1;
        node->class_counts = (float*)malloc(data->classes * sizeof(float));
        rf_fill_class_counts(f, data, rows, n, node->class_counts);
        return idx;
    }

    node->is_leaf = 0;
    node->feature = best.feature;
    node->threshold = best.threshold;
    node->split_type = best.split_type;
    node->missing_go_left = best.missing_go_left;
    
    // Recursive calls may realloc t->nodes, so we must use idx not node pointer
    int left_idx = rf_build_node(f, data, t, left_rows, left_n, depth + 1);
    int right_idx = rf_build_node(f, data, t, right_rows, right_n, depth + 1);
    
    // Re-fetch node pointer after potential realloc
    t->nodes[idx].left = left_idx;
    t->nodes[idx].right = right_idx;

    free(left_rows);
    free(right_rows);
    return idx;
}

static void rf_train_tree(MiyoForest* f, MiyoRFData* data, MiyoRFTree* t)
{
    int n = data->rows;
    int sample_n = n;
    if(f->cfg.sample_rate > 0.0f && f->cfg.sample_rate < 1.0f)
    {
        sample_n = (int)(f->cfg.sample_rate * (float)n);
        if(sample_n < 1) sample_n = 1;
    }
    int* rows = (int*)malloc(sample_n * sizeof(int));
    if(f->cfg.bootstrap)
    {
        for(int i = 0; i < sample_n; i++)
            rows[i] = rf_rand_int(f, n);
    }
    else
    {
        if(sample_n == n)
        {
            for(int i = 0; i < sample_n; i++)
                rows[i] = i;
        }
        else
        {
            int* all = (int*)malloc(n * sizeof(int));
            for(int i = 0; i < n; i++)
                all[i] = i;
            for(int i = 0; i < sample_n; i++)
            {
                int j = i + rf_rand_int(f, n - i);
                int tmp = all[i]; all[i] = all[j]; all[j] = tmp;
                rows[i] = all[i];
            }
            free(all);
        }
    }

    rf_build_node(f, data, t, rows, sample_n, 0);
    free(rows);
}

MiyoRFConfig miyo_rf_config_default(void)
{
    MiyoRFConfig c;
    c.n_trees = 50;
    c.max_depth = 12;
    c.min_samples_split = 2;
    c.max_features = 0;
    c.bootstrap = 1;
    c.sample_rate = 1.0f;
    c.split_candidates = 8;
    c.interval_split = 1;
    c.quality_exp = 1.0f;
    c.interval_penalty = 0.0f;
    return c;
}

MiyoForest miyo_rf_build(MiyoRFConfig cfg, int cols, int classes)
{
    MiyoForest f;
    memset(&f, 0, sizeof(MiyoForest));
    f.cfg = cfg;
    f.cols = cols;
    f.classes = classes;
    f.n_trees = (cfg.n_trees > 0) ? cfg.n_trees : 1;
    f.built_trees = 0;
    f.trees = (MiyoRFTree*)malloc(f.n_trees * sizeof(MiyoRFTree));
    for(int i = 0; i < f.n_trees; i++)
        rf_tree_init(&f.trees[i]);
    f.rng = (unsigned int)rand();
    return f;
}

void miyo_rf_free(MiyoForest f)
{
    for(int i = 0; i < f.n_trees; i++)
        rf_tree_free(&f.trees[i]);
    if(f.trees) free(f.trees);
}

int miyo_rf_expand(MiyoForest* f, int new_total_trees)
{
    if(new_total_trees <= f->n_trees) return 0;
    MiyoRFTree* new_trees = (MiyoRFTree*)realloc(f->trees, new_total_trees * sizeof(MiyoRFTree));
    if(new_trees == NULL) return 0;
    f->trees = new_trees;
    for(int i = f->n_trees; i < new_total_trees; i++)
        rf_tree_init(&f->trees[i]);
    f->n_trees = new_total_trees;
    f->cfg.n_trees = new_total_trees;
    return 1;
}

void miyo_rf_train(MiyoForest* f, MiyoRFData data)
{
    if(data.rows <= 0 || data.cols <= 0 || data.classes <= 0) return;
    if(f->cols != data.cols || f->classes != data.classes) return;

    for(int i = f->built_trees; i < f->n_trees; i++)
    {
        rf_train_tree(f, &data, &f->trees[i]);
        f->built_trees++;
    }
}

int miyo_rf_built_trees(MiyoForest* f)
{
    return f->built_trees;
}

int miyo_rf_total_trees(MiyoForest* f)
{
    return f->n_trees;
}

static void rf_tree_predict(MiyoForest* f, MiyoRFTree* t, MiyoRFData* data, int row, float* out_counts)
{
    int node_idx = 0;
    while(node_idx >= 0)
    {
        MiyoRFNode* node = &t->nodes[node_idx];
        if(node->is_leaf)
        {
            for(int k = 0; k < data->classes; k++)
                out_counts[k] = out_counts[k] + node->class_counts[k];
            return;
        }

        int feature = node->feature;
        int missing = rf_is_missing(data, row, feature);
        if(node->split_type == MIYO_RF_SPLIT_MISSING)
        {
            if(missing)
                node_idx = node->missing_go_left ? node->left : node->right;
            else
                node_idx = node->missing_go_left ? node->right : node->left;
            continue;
        }
        if(missing)
        {
            node_idx = node->missing_go_left ? node->left : node->right;
            continue;
        }
        if(node->split_type == MIYO_RF_SPLIT_WIDTH)
        {
            float width = rf_has_interval(data) ? rf_get_width(data, row, feature) : 0.0f;
            node_idx = (width <= node->threshold) ? node->left : node->right;
            continue;
        }
        node_idx = rf_interval_go_left(f, data, row, feature, node->threshold) ? node->left : node->right;
        continue;
    }
}

void miyo_rf_predict_proba(MiyoForest* f, MiyoRFData data, int row, float* out_probs)
{
    for(int k = 0; k < data.classes; k++) out_probs[k] = 0.0f;
    if(f->built_trees == 0) return;
    if(data.cols != f->cols || data.classes != f->classes) return;
    if(row < 0 || row >= data.rows) return;

    float* temp = (float*)malloc(data.classes * sizeof(float));
    for(int t = 0; t < f->built_trees; t++)
    {
        for(int k = 0; k < data.classes; k++) temp[k] = 0.0f;
        rf_tree_predict(f, &f->trees[t], &data, row, temp);

        float sum = 0.0f;
        for(int k = 0; k < data.classes; k++) sum = sum + temp[k];
        if(sum > 0.0f)
        {
            for(int k = 0; k < data.classes; k++)
                out_probs[k] = out_probs[k] + (temp[k] / sum);
        }
    }
    free(temp);

    float total = 0.0f;
    for(int k = 0; k < data.classes; k++) total = total + out_probs[k];
    if(total <= 0.0f) return;
    for(int k = 0; k < data.classes; k++) out_probs[k] = out_probs[k] / total;
}

int miyo_rf_predict(MiyoForest* f, MiyoRFData data, int row)
{
    if(data.cols != f->cols || data.classes != f->classes) return -1;
    if(row < 0 || row >= data.rows) return -1;
    float* probs = (float*)malloc(data.classes * sizeof(float));
    miyo_rf_predict_proba(f, data, row, probs);
    int best = 0;
    float best_v = probs[0];
    for(int k = 1; k < data.classes; k++)
    {
        if(probs[k] > best_v)
        {
            best_v = probs[k];
            best = k;
        }
    }
    free(probs);
    return best;
}

void miyo_rf_save(MiyoForest f, const char* path)
{
    FILE* fp = fopen(path, "w");
    if(fp == NULL) return;

    fprintf(fp, "MIYO_RF 1\n");
    fprintf(fp, "%d %d %d %d\n", f.cols, f.classes, f.n_trees, f.built_trees);
    fprintf(fp, "%d %d %d %d %d %d\n",
            f.cfg.max_depth, f.cfg.min_samples_split, f.cfg.max_features,
            f.cfg.bootstrap, f.cfg.split_candidates, f.cfg.interval_split);
    fprintf(fp, "%.9g %.9g %.9g\n",
            (double)f.cfg.sample_rate, (double)f.cfg.quality_exp, (double)f.cfg.interval_penalty);
    fprintf(fp, "%u\n", f.rng);

    for(int t = 0; t < f.built_trees; t++)
    {
        MiyoRFTree* tr = &f.trees[t];
        fprintf(fp, "%d\n", tr->node_count);
        for(int i = 0; i < tr->node_count; i++)
        {
            MiyoRFNode* n = &tr->nodes[i];
            fprintf(fp, "%d %d %d %d %d %.9g\n",
                    n->is_leaf, n->feature, n->split_type, n->missing_go_left,
                    n->left, (double)n->threshold);
            fprintf(fp, "%d\n", n->right);
            if(n->is_leaf)
            {
                for(int k = 0; k < f.classes; k++)
                    fprintf(fp, "%.9g ", (double)n->class_counts[k]);
                fprintf(fp, "\n");
            }
        }
    }
    fclose(fp);
}

MiyoForest miyo_rf_load(const char* path)
{
    MiyoForest f;
    memset(&f, 0, sizeof(MiyoForest));
    FILE* fp = fopen(path, "r");
    if(fp == NULL) return f;

    char header[32];
    if(fscanf(fp, "%s", header) != 1)
    {
        fclose(fp);
        return f;
    }
    if(strcmp(header, "MIYO_RF") != 0)
    {
        fclose(fp);
        return f;
    }
    int version = 0;
    if(fscanf(fp, "%d\n", &version) != 1)
    {
        fclose(fp);
        return f;
    }

    int cols, classes, n_trees, built_trees;
    if(fscanf(fp, "%d %d %d %d\n", &cols, &classes, &n_trees, &built_trees) != 4)
    {
        fclose(fp);
        return f;
    }
    f.cols = cols;
    f.classes = classes;
    f.n_trees = n_trees;
    f.built_trees = built_trees;

    if(fscanf(fp, "%d %d %d %d %d %d\n",
              &f.cfg.max_depth, &f.cfg.min_samples_split, &f.cfg.max_features,
              &f.cfg.bootstrap, &f.cfg.split_candidates, &f.cfg.interval_split) != 6)
    {
        fclose(fp);
        return f;
    }
    if(fscanf(fp, "%f %f %f\n", &f.cfg.sample_rate, &f.cfg.quality_exp, &f.cfg.interval_penalty) != 3)
    {
        fclose(fp);
        return f;
    }
    if(fscanf(fp, "%u\n", &f.rng) != 1)
    {
        fclose(fp);
        return f;
    }
    f.cfg.n_trees = f.n_trees;

    f.trees = (MiyoRFTree*)malloc(f.n_trees * sizeof(MiyoRFTree));
    for(int i = 0; i < f.n_trees; i++)
        rf_tree_init(&f.trees[i]);

    for(int t = 0; t < f.built_trees; t++)
    {
        MiyoRFTree* tr = &f.trees[t];
        int node_count = 0;
        if(fscanf(fp, "%d\n", &node_count) != 1 || node_count <= 0)
        {
            miyo_rf_free(f);
            memset(&f, 0, sizeof(MiyoForest));
            fclose(fp);
            return f;
        }
        tr->nodes = (MiyoRFNode*)malloc(node_count * sizeof(MiyoRFNode));
        tr->node_count = node_count;
        tr->node_capacity = node_count;
        for(int i = 0; i < node_count; i++)
        {
            MiyoRFNode* n = &tr->nodes[i];
            memset(n, 0, sizeof(MiyoRFNode));
            n->left = -1;
            n->right = -1;
            if(fscanf(fp, "%d %d %d %d %d %f\n",
                      &n->is_leaf, &n->feature, &n->split_type, &n->missing_go_left,
                      &n->left, &n->threshold) != 6)
            {
                miyo_rf_free(f);
                memset(&f, 0, sizeof(MiyoForest));
                fclose(fp);
                return f;
            }
            if(fscanf(fp, "%d\n", &n->right) != 1)
            {
                miyo_rf_free(f);
                memset(&f, 0, sizeof(MiyoForest));
                fclose(fp);
                return f;
            }
            if(n->is_leaf)
            {
                n->class_counts = (float*)malloc(f.classes * sizeof(float));
                for(int k = 0; k < f.classes; k++)
                {
                    if(fscanf(fp, "%f ", &n->class_counts[k]) != 1)
                    {
                        miyo_rf_free(f);
                        memset(&f, 0, sizeof(MiyoForest));
                        fclose(fp);
                        return f;
                    }
                }
            }
            else
            {
                n->class_counts = NULL;
            }
        }
    }

    fclose(fp);
    return f;
}
