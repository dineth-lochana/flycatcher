#ifndef MIYO_H
#define MIYO_H

// Activation functions
typedef enum
{
    MIYO_ACT_SIGMOID,
    MIYO_ACT_TANH,
    MIYO_ACT_RELU,
    MIYO_ACT_LEAKY_RELU,
    MIYO_ACT_SOFTMAX
}
MiyoActivation;

// Weight initialization
typedef enum
{
    MIYO_INIT_RANDOM,
    MIYO_INIT_XAVIER,
    MIYO_INIT_HE
}
MiyoWeightInit;

// Optimizer types
typedef enum
{
    MIYO_OPT_SGD,
    MIYO_OPT_MOMENTUM,
    MIYO_OPT_RMSPROP
}
MiyoOptimizer;

// Loss functions
typedef enum
{
    MIYO_LOSS_MSE,
    MIYO_LOSS_CROSS_ENTROPY
}
MiyoLoss;

// Learning rate schedule
typedef enum
{
    MIYO_LR_CONSTANT,
    MIYO_LR_STEP_DECAY,
    MIYO_LR_EXPONENTIAL,
    MIYO_LR_COSINE
}
MiyoLRSchedule;

// Single layer
typedef struct
{
    int in_size;
    int out_size;
    float* weights;
    float* biases;
    float* output;
    float* output_pre_dropout;
    float* pre_act;
    float* delta;
    float* grad_w;
    float* grad_b;
    // Optimizer cache
    float* cache_w;
    float* cache_b;
    // Dropout
    int* dropout_mask;
    // Config
    MiyoActivation act;
    float dropout_rate;
}
MiyoLayer;

// Early stopping
typedef struct
{
    float best_error;
    int patience;
    int wait_count;
    int enabled;
    float min_delta;
}
MiyoEarlyStopping;

// Learning rate scheduler
typedef struct
{
    MiyoLRSchedule type;
    float initial_lr;
    float current_lr;
    int step_size;
    float decay_rate;
    int total_epochs;
    int current_epoch;
}
MiyoLRScheduler;

// Network config
typedef struct
{
    int* layer_sizes;
    int num_layers;
    MiyoActivation* layer_acts;
    float learning_rate;
    MiyoOptimizer optimizer;
    float momentum;
    float rmsprop_decay;
    float rmsprop_epsilon;
    float l2_lambda;
    float dropout_rate;
    float grad_clip;
    MiyoLoss loss_type;
    MiyoWeightInit init_type;
    MiyoLRSchedule lr_schedule;
    float lr_decay_rate;
    int lr_step_size;
    int total_epochs;
    int early_stop_patience;
    float early_stop_delta;
}
MiyoConfig;

// Main network
typedef struct
{
    MiyoLayer* layers;
    int num_layers;
    int nips;
    int nops;
    // State
    MiyoEarlyStopping* early_stop;
    MiyoLRScheduler* lr_sched;
    // Mini-batch
    int batch_count;
    float batch_loss;
    // Config
    MiyoOptimizer optimizer;
    float momentum;
    float rmsprop_decay;
    float rmsprop_epsilon;
    float l2_lambda;
    float grad_clip;
    float base_lr;
    MiyoLoss loss_type;
    int training;
}
Miyo;

MiyoConfig miyo_config_default(void);

Miyo miyo_build(MiyoConfig cfg);

void miyo_free(Miyo m);

float* miyo_predict(Miyo* m, const float* input);

float miyo_train(Miyo* m, const float* input, const float* target, float lr);

void miyo_batch_accumulate(Miyo* m, const float* input, const float* target);

float miyo_batch_update(Miyo* m, float lr);

void miyo_epoch_start(Miyo* m);

void miyo_epoch_end(Miyo* m);

float miyo_get_lr(Miyo* m);

int miyo_early_stop_check(Miyo* m, float error);

void miyo_save(Miyo m, const char* path);

Miyo miyo_load(const char* path);

void miyo_set_training(Miyo* m, int training);

void miyo_print(const float* arr, int size);

#endif
