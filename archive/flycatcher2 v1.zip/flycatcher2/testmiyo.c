// set SMLRASM=n2f.exe
// set SMLRC=C:\Users\DinethLochana\Downloads\C\smlrc
// smlrcc -Wall -win -SI include -SL lib miyo.c testmiyo.c -o testmiyo.exe

#include "miyo.h"
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

#define FLT_MAX_VAL 3.402823466e+38f

typedef struct
{
    float** in;
    float** tg;
    int nips;
    int nops;
    int rows;
}
Data;

typedef struct
{
    MiyoWeightInit init;
    MiyoActivation hidden_act;
    MiyoOptimizer optimizer;
    MiyoLoss loss;
    float dropout;
    float l2_lambda;
    float learning_rate;
    int nhid1;
    int nhid2;
    float final_error;
    float accuracy;
}
GridResult;

static int lns(FILE* const file)
{
    int ch = EOF;
    int lines = 0;
    int pc = '\n';
    while((ch = getc(file)) != EOF)
    {
        if(ch == '\n')
            lines++;
        pc = ch;
    }
    if(pc != '\n')
        lines++;
    rewind(file);
    return lines;
}

static char* readln(FILE* const file)
{
    int ch = EOF;
    int reads = 0;
    int size = 128;
    char* line = (char*)malloc(size * sizeof(char));
    while((ch = getc(file)) != '\n' && ch != EOF)
    {
        line[reads++] = ch;
        if(reads + 1 == size)
            line = (char*)realloc(line, (size *= 2) * sizeof(char));
    }
    line[reads] = '\0';
    return line;
}

static float** new2d(const int rows, const int cols)
{
    float** row = (float**)malloc(rows * sizeof(float*));
    for(int r = 0; r < rows; r++)
        row[r] = (float*)malloc(cols * sizeof(float));
    return row;
}

static Data ndata(const int nips, const int nops, const int rows)
{
    Data data;
    data.in = new2d(rows, nips);
    data.tg = new2d(rows, nops);
    data.nips = nips;
    data.nops = nops;
    data.rows = rows;
    return data;
}

static void parse(const Data data, char* line, const int row)
{
    const int cols = data.nips + data.nops;
    for(int col = 0; col < cols; col++)
    {
        const float val = atof(strtok(col == 0 ? line : NULL, " "));
        if(col < data.nips)
            data.in[row][col] = val;
        else
            data.tg[row][col - data.nips] = val;
    }
}

static void parse_csv(const Data data, char* line, const int row)
{
    // Supports up to 300 columns (enough for Semeion 256+10 and Wine 14)
    float vals[300];
    int count = 0;
    char* tok = strtok(line, ",");
    while(tok != NULL && count < 300)
    {
        vals[count++] = (float)atof(tok);
        tok = strtok(NULL, ",");
    }

    // Case 1: full (features + one-hot targets) already in file
    if(count == data.nips + data.nops)
    {
        for(int col = 0; col < data.nips; col++)
            data.in[row][col] = vals[col];
        for(int col = 0; col < data.nops; col++)
            data.tg[row][col] = vals[data.nips + col];
        return;
    }

    // Case 2: label + features (e.g., Wine: class first, 13 features)
    if(count == data.nips + 1 && data.nops > 1)
    {
        int cls = (int)vals[0];
        if(cls < 1) cls = 1;
        if(cls > data.nops) cls = data.nops;

        for(int col = 0; col < data.nops; col++)
            data.tg[row][col] = 0.0f;
        data.tg[row][cls - 1] = 1.0f;

        for(int col = 0; col < data.nips; col++)
            data.in[row][col] = vals[col + 1];
        return;
    }

    // Fallback: fill zeros to avoid crashes
    for(int col = 0; col < data.nips; col++)
        data.in[row][col] = (col < count) ? vals[col] : 0.0f;
    for(int col = 0; col < data.nops; col++)
        data.tg[row][col] = 0.0f;
}

static void dfree(const Data d)
{
    for(int row = 0; row < d.rows; row++)
    {
        free(d.in[row]);
        free(d.tg[row]);
    }
    free(d.in);
    free(d.tg);
}

// Normalize data using min-max scaling to [0,1]
static void normalize_data(Data d)
{
    for(int j = 0; j < d.nips; j++)
    {
        float min_v = d.in[0][j];
        float max_v = d.in[0][j];
        for(int i = 1; i < d.rows; i++)
        {
            if(d.in[i][j] < min_v) min_v = d.in[i][j];
            if(d.in[i][j] > max_v) max_v = d.in[i][j];
        }
        float range = max_v - min_v;
        if(range > 1e-8f)
        {
            for(int i = 0; i < d.rows; i++)
                d.in[i][j] = (d.in[i][j] - min_v) / range;
        }
    }
}

static void shuffle(const Data d)
{
    for(int a = 0; a < d.rows; a++)
    {
        const int b = rand() % d.rows;
        float* ot = d.tg[a];
        float* it = d.in[a];
        d.tg[a] = d.tg[b];
        d.tg[b] = ot;
        d.in[a] = d.in[b];
        d.in[b] = it;
    }
}

static Data build(const char* path, const int nips, const int nops, int use_csv)
{
    FILE* file = fopen(path, "r");
    if(file == NULL)
    {
        printf("Could not open %s\n", path);
        exit(1);
    }
    const int rows = lns(file);
    Data data = ndata(nips, nops, rows);
    for(int row = 0; row < rows; row++)
    {
        char* line = readln(file);
        if(use_csv)
            parse_csv(data, line, row);
        else
            parse(data, line, row);
        free(line);
    }
    fclose(file);
    return data;
}

static Data split_data(const Data full, int start, int end)
{
    int size = end - start;
    Data subset = ndata(full.nips, full.nops, size);
    for(int i = 0; i < size; i++)
    {
        for(int j = 0; j < full.nips; j++)
            subset.in[i][j] = full.in[start + i][j];
        for(int j = 0; j < full.nops; j++)
            subset.tg[i][j] = full.tg[start + i][j];
    }
    return subset;
}

static float calc_accuracy(Miyo* m, const Data test)
{
    int correct = 0;
    miyo_set_training(m, 0);
    
    for(int i = 0; i < test.rows; i++)
    {
        const float* pred = miyo_predict(m, test.in[i]);
        int pred_class = 0;
        int true_class = 0;
        float max_pred = pred[0];
        float max_true = test.tg[i][0];
        
        for(int j = 1; j < test.nops; j++)
        {
            if(pred[j] > max_pred)
            {
                max_pred = pred[j];
                pred_class = j;
            }
            if(test.tg[i][j] > max_true)
            {
                max_true = test.tg[i][j];
                true_class = j;
            }
        }
        
        if(pred_class == true_class)
            correct++;
    }
    
    miyo_set_training(m, 1);
    return (float)correct / test.rows;
}

static const char* init_name(MiyoWeightInit i)
{
    if(i == MIYO_INIT_RANDOM) return "Random";
    if(i == MIYO_INIT_XAVIER) return "Xavier";
    return "He";
}

static const char* act_name(MiyoActivation a)
{
    if(a == MIYO_ACT_SIGMOID) return "Sigmoid";
    if(a == MIYO_ACT_TANH) return "Tanh";
    if(a == MIYO_ACT_RELU) return "ReLU";
    if(a == MIYO_ACT_LEAKY_RELU) return "LReLU";
    return "Softmax";
}

static const char* opt_name(MiyoOptimizer o)
{
    if(o == MIYO_OPT_SGD) return "SGD";
    if(o == MIYO_OPT_MOMENTUM) return "Momentum";
    return "RMSprop";
}

static const char* loss_name(MiyoLoss l)
{
    if(l == MIYO_LOSS_MSE) return "MSE";
    return "CrossEnt";
}

static int rand_choice(int max_val)
{
    return rand() % max_val;
}

static float rand_float(float min_v, float max_v)
{
    float range = max_v - min_v;
    return min_v + ((float)rand() / (float)RAND_MAX) * range;
}

static GridResult run_config(const Data train, const Data test,
                             MiyoWeightInit init, MiyoActivation hidden_act,
                             MiyoOptimizer opt, MiyoLoss loss, float dropout,
                             float l2, float lr, int nhid1, int nhid2, int iterations)
{
    GridResult result;
    result.init = init;
    result.hidden_act = hidden_act;
    result.optimizer = opt;
    result.loss = loss;
    result.dropout = dropout;
    result.l2_lambda = l2;
    result.learning_rate = lr;
    result.nhid1 = nhid1;
    result.nhid2 = nhid2;
    
    int layer_sizes[4];
    int num_layers;
    
    if(nhid2 > 0)
    {
        layer_sizes[0] = train.nips;
        layer_sizes[1] = nhid1;
        layer_sizes[2] = nhid2;
        layer_sizes[3] = train.nops;
        num_layers = 4;
    }
    else
    {
        layer_sizes[0] = train.nips;
        layer_sizes[1] = nhid1;
        layer_sizes[2] = train.nops;
        num_layers = 3;
    }
    
    MiyoActivation acts[3];
    int act_count = num_layers - 1;
    for(int i = 0; i < act_count - 1; i++)
        acts[i] = hidden_act;
    acts[act_count - 1] = (loss == MIYO_LOSS_CROSS_ENTROPY) ? MIYO_ACT_SOFTMAX : MIYO_ACT_SIGMOID;
    
    MiyoConfig cfg = miyo_config_default();
    cfg.layer_sizes = layer_sizes;
    cfg.num_layers = num_layers;
    cfg.layer_acts = acts;
    cfg.learning_rate = lr;
    cfg.optimizer = opt;
    cfg.momentum = 0.9f;
    cfg.rmsprop_decay = 0.9f;
    cfg.l2_lambda = l2;
    cfg.dropout_rate = dropout;
    cfg.grad_clip = 5.0f;
    cfg.loss_type = loss;
    cfg.init_type = init;
    cfg.lr_schedule = MIYO_LR_EXPONENTIAL;
    cfg.lr_decay_rate = 0.99f;
    cfg.total_epochs = iterations;
    cfg.early_stop_patience = 15;
    cfg.early_stop_delta = 0.0001f;
    
    Miyo m = miyo_build(cfg);
    float final_error = 0.0f;
    int batch_size = 32;
    
    for(int iter = 0; iter < iterations; iter++)
    {
        miyo_epoch_start(&m);
        float lr_now = miyo_get_lr(&m);
        float epoch_loss = 0.0f;
        int batch_count = 0;
        
        // Mini-batch training
        for(int j = 0; j < train.rows; j++)
        {
            miyo_batch_accumulate(&m, train.in[j], train.tg[j]);
            
            if((j + 1) % batch_size == 0 || j == train.rows - 1)
            {
                epoch_loss = epoch_loss + miyo_batch_update(&m, lr_now);
                batch_count++;
            }
        }
        
        final_error = epoch_loss / batch_count;
        
        if(miyo_early_stop_check(&m, final_error))
            break;
        
        miyo_epoch_end(&m);
    }
    
    result.final_error = final_error;
    result.accuracy = calc_accuracy(&m, test);
    
    miyo_free(m);
    return result;
}

static void print_result(GridResult r, int num)
{
    printf("Config %d: Init=%s Act=%s Opt=%s Loss=%s ",
           num, init_name(r.init), act_name(r.hidden_act),
           opt_name(r.optimizer), loss_name(r.loss));
    printf("Drop=%.2f L2=%.4f LR=%.3f Hid=%d/%d -> ",
           (double)r.dropout, (double)r.l2_lambda, (double)r.learning_rate,
           r.nhid1, r.nhid2);
    printf("Err=%.6f Acc=%.4f\n", (double)r.final_error, (double)r.accuracy);
}

static void test_dataset(const char* name, const char* path,
                        int nips, int nops, int use_csv, int iterations)
{
    printf("\nTesting %s dataset\n", name);
    printf("Inputs: %d, Outputs: %d\n\n", nips, nops);
    
    Data full_data = build(path, nips, nops, use_csv);
    normalize_data(full_data);
    shuffle(full_data);
    
    const int train_size = (int)(full_data.rows * 0.8f);
    const Data train = split_data(full_data, 0, train_size);
    const Data test = split_data(full_data, train_size, full_data.rows);
    
    printf("Train: %d, Test: %d\n\n", train.rows, test.rows);
    
    // Hyperparameter choices
    MiyoWeightInit inits[] = {MIYO_INIT_XAVIER, MIYO_INIT_HE};
    MiyoActivation acts[] = {MIYO_ACT_TANH, MIYO_ACT_RELU, MIYO_ACT_LEAKY_RELU};
    MiyoOptimizer opts[] = {MIYO_OPT_SGD, MIYO_OPT_MOMENTUM, MIYO_OPT_RMSPROP};
    MiyoLoss losses[] = {MIYO_LOSS_MSE, MIYO_LOSS_CROSS_ENTROPY};
    
	// Should be around 50
    int n_trials = 10;
    printf("Running Random Search: %d trials\n\n", n_trials);
    
    GridResult best;
    best.accuracy = 0.0f;
    best.final_error = FLT_MAX_VAL;
    
    for(int trial = 0; trial < n_trials; trial++)
    {
        MiyoWeightInit init = inits[rand_choice(2)];
        MiyoActivation act = acts[rand_choice(3)];
        MiyoOptimizer opt = opts[rand_choice(3)];
        MiyoLoss loss = losses[rand_choice(2)];
        
        float dropout = rand_float(0.0f, 0.3f);
        float l2 = rand_float(0.0f, 0.01f);
        float lr = rand_float(0.001f, 0.1f);
        
        int min_hid = nips / 2;
        if(min_hid < 4) min_hid = 4;
        int max_hid = nips * 2;
        int nhid1 = min_hid + rand_choice(max_hid - min_hid + 1);
        
        int nhid2 = 0;
        if(rand_choice(2))
            nhid2 = min_hid / 2 + rand_choice(max_hid / 2);
        
        GridResult r = run_config(train, test, init, act, opt, loss,
                                  dropout, l2, lr, nhid1, nhid2, iterations);
        
        if((trial + 1) % 10 == 0 || r.accuracy > best.accuracy)
            print_result(r, trial + 1);
        
        if(r.accuracy > best.accuracy)
            best = r;
    }
    
    printf("\nBest Configuration:\n");
    print_result(best, -1);
    
    // Test defaults
    printf("\nDefault Configurations:\n");
    
    GridResult d1 = run_config(train, test, MIYO_INIT_HE,
                               MIYO_ACT_RELU, MIYO_OPT_RMSPROP, MIYO_LOSS_CROSS_ENTROPY,
                               0.2f, 0.001f, 0.01f, nips, nips/2, iterations);
    printf("Default 1 (He/ReLU/RMSprop/CE/2-layer): ");
    printf("Err=%.6f Acc=%.4f\n", (double)d1.final_error, (double)d1.accuracy);
    
    GridResult d2 = run_config(train, test, MIYO_INIT_XAVIER,
                               MIYO_ACT_TANH, MIYO_OPT_MOMENTUM, MIYO_LOSS_MSE,
                               0.0f, 0.0f, 0.05f, nips, 0, iterations);
    printf("Default 2 (Xavier/Tanh/Momentum/MSE/1-layer): ");
    printf("Err=%.6f Acc=%.4f\n", (double)d2.final_error, (double)d2.accuracy);
    
    dfree(train);
    dfree(test);
    dfree(full_data);
}

static void test_xor(void)
{
    printf("Testing XOR...\n");
    
    float in0[] = {0, 0};
    float in1[] = {0, 1};
    float in2[] = {1, 0};
    float in3[] = {1, 1};
    float tg0[] = {0};
    float tg1[] = {1};
    float tg2[] = {1};
    float tg3[] = {0};
    
/*     float* inputs[] = {in0, in1, in2, in3};
    float* targets[] = {tg0, tg1, tg2, tg3}; */
	
float* inputs[4];
float* targets[4];

inputs[0] = in0;  inputs[1] = in1;  inputs[2] = in2;  inputs[3] = in3;
targets[0] = tg0; targets[1] = tg1; targets[2] = tg2; targets[3] = tg3;
    
    int sizes[] = {2, 4, 1};
    MiyoActivation acts[] = {MIYO_ACT_TANH, MIYO_ACT_SIGMOID};
    
    MiyoConfig cfg = miyo_config_default();
    cfg.layer_sizes = sizes;
    cfg.num_layers = 3;
    cfg.layer_acts = acts;
    cfg.learning_rate = 0.5f;
    cfg.optimizer = MIYO_OPT_MOMENTUM;
    cfg.momentum = 0.9f;
    cfg.init_type = MIYO_INIT_XAVIER;
    cfg.loss_type = MIYO_LOSS_MSE;
    
    Miyo m = miyo_build(cfg);
    
    for(int epoch = 0; epoch < 2000; epoch++)
    {
        float error = 0.0f;
        for(int i = 0; i < 4; i++)
            error = error + miyo_train(&m, inputs[i], targets[i], 0.5f);
        if((epoch + 1) % 500 == 0)
            printf("Epoch %d: error=%.6f\n", epoch + 1, (double)(error / 4.0f));
    }
    
    printf("\nPredictions:\n");
    miyo_set_training(&m, 0);
    for(int i = 0; i < 4; i++)
    {
        float* pred = miyo_predict(&m, inputs[i]);
        printf("  [%.0f, %.0f] -> %.4f (expected %.0f)\n",
               (double)inputs[i][0], (double)inputs[i][1],
               (double)pred[0], (double)targets[i][0]);
    }
    
    // Test save/load
    printf("\nTesting save/load...\n");
    miyo_save(m, "xor.miyo");
    miyo_free(m);
    
    Miyo loaded = miyo_load("xor.miyo");
    miyo_set_training(&loaded, 0);
    printf("Loaded predictions:\n");
    for(int i = 0; i < 4; i++)
    {
        float* pred = miyo_predict(&loaded, inputs[i]);
        printf("  [%.0f, %.0f] -> %.4f\n",
               (double)inputs[i][0], (double)inputs[i][1], (double)pred[0]);
    }
    miyo_free(loaded);
    
    printf("XOR test complete!\n\n");
}

static void test_resume_training(void)
{
    printf("Testing training resume...\n");
    
    float in0[] = {0, 0};
    float in1[] = {0, 1};
    float in2[] = {1, 0};
    float in3[] = {1, 1};
    float tg0[] = {0};
    float tg1[] = {1};
    float tg2[] = {1};
    float tg3[] = {0};
    
/*     float* inputs[] = {in0, in1, in2, in3};
    float* targets[] = {tg0, tg1, tg2, tg3}; */
	
	float* inputs[4];
float* targets[4];

inputs[0] = in0;  inputs[1] = in1;  inputs[2] = in2;  inputs[3] = in3;
targets[0] = tg0; targets[1] = tg1; targets[2] = tg2; targets[3] = tg3;
    
    int sizes[] = {2, 8, 1};
    MiyoActivation acts[] = {MIYO_ACT_RELU, MIYO_ACT_SIGMOID};
    
    MiyoConfig cfg = miyo_config_default();
    cfg.layer_sizes = sizes;
    cfg.num_layers = 3;
    cfg.layer_acts = acts;
    cfg.learning_rate = 0.1f;
    cfg.optimizer = MIYO_OPT_RMSPROP;
    cfg.rmsprop_decay = 0.9f;
    cfg.init_type = MIYO_INIT_HE;
    cfg.loss_type = MIYO_LOSS_MSE;
    cfg.lr_schedule = MIYO_LR_EXPONENTIAL;
    cfg.lr_decay_rate = 0.99f;
    cfg.total_epochs = 2000;
    cfg.early_stop_patience = 50;
    cfg.early_stop_delta = 0.0001f;
    
    Miyo m = miyo_build(cfg);
    
    // Train for 500 epochs
    printf("Phase 1: Training for 500 epochs...\n");
    for(int epoch = 0; epoch < 500; epoch++)
    {
        miyo_epoch_start(&m);
        float lr = miyo_get_lr(&m);
        float error = 0.0f;
        for(int i = 0; i < 4; i++)
            error = error + miyo_train(&m, inputs[i], targets[i], lr);
        miyo_epoch_end(&m);
        if((epoch + 1) % 100 == 0)
            printf("  Epoch %d: error=%.6f lr=%.6f\n", epoch + 1, (double)(error / 4.0f), (double)lr);
    }
    
    // Save checkpoint
    printf("Saving checkpoint...\n");
    miyo_save(m, "resume_test.miyo");
    
    // Continue training original for 500 more epochs
    printf("Phase 2a: Continue original for 500 more epochs...\n");
    for(int epoch = 500; epoch < 1000; epoch++)
    {
        miyo_epoch_start(&m);
        float lr = miyo_get_lr(&m);
        float error = 0.0f;
        for(int i = 0; i < 4; i++)
            error = error + miyo_train(&m, inputs[i], targets[i], lr);
        miyo_epoch_end(&m);
        if((epoch + 1) % 100 == 0)
            printf("  Epoch %d: error=%.6f lr=%.6f\n", epoch + 1, (double)(error / 4.0f), (double)lr);
    }
    
    miyo_set_training(&m, 0);
    printf("Original final predictions:\n");
    for(int i = 0; i < 4; i++)
    {
        float* pred = miyo_predict(&m, inputs[i]);
        printf("  [%.0f, %.0f] -> %.4f (expected %.0f)\n",
               (double)inputs[i][0], (double)inputs[i][1],
               (double)pred[0], (double)targets[i][0]);
    }
    miyo_free(m);
    
    // Load checkpoint and resume
    printf("\nPhase 2b: Load checkpoint and resume for 500 epochs...\n");
    Miyo loaded = miyo_load("resume_test.miyo");
    miyo_set_training(&loaded, 1);
    
    for(int epoch = 500; epoch < 1000; epoch++)
    {
        miyo_epoch_start(&loaded);
        float lr = miyo_get_lr(&loaded);
        float error = 0.0f;
        for(int i = 0; i < 4; i++)
            error = error + miyo_train(&loaded, inputs[i], targets[i], lr);
        miyo_epoch_end(&loaded);
        if((epoch + 1) % 100 == 0)
            printf("  Epoch %d: error=%.6f lr=%.6f\n", epoch + 1, (double)(error / 4.0f), (double)lr);
    }
    
    miyo_set_training(&loaded, 0);
    printf("Resumed final predictions:\n");
    for(int i = 0; i < 4; i++)
    {
        float* pred = miyo_predict(&loaded, inputs[i]);
        printf("  [%.0f, %.0f] -> %.4f (expected %.0f)\n",
               (double)inputs[i][0], (double)inputs[i][1],
               (double)pred[0], (double)targets[i][0]);
    }
    miyo_free(loaded);
    
    printf("Resume training test complete!\n\n");
}

int main(void)
{
    srand(time(0));
    printf("Miyo Neural Network\n\n");
    
    test_xor();
    test_resume_training();
    test_dataset("Semeion", "semeion.data", 256, 10, 0, 64);
    test_dataset("Wine", "wine.data", 13, 3, 1, 128);
    
    printf("\nComplete!\n");
    return 0;
}
