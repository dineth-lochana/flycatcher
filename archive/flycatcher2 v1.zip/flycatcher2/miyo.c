#include "miyo.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

// Random float [0, 1]
static float frand(void)
{
    return rand() / (float)RAND_MAX;
}

// Random float [-1, 1]
static float frand_sym(void)
{
    return frand() * 2.0f - 1.0f;
}

// Activations
static float act_sigmoid(float x)
{
    return 1.0f / (1.0f + expf(-x));
}

static float act_tanh(float x)
{
    return tanhf(x);
}

static float act_relu(float x)
{
    return x > 0.0f ? x : 0.0f;
}

static float act_leaky_relu(float x)
{
    return x > 0.0f ? x : 0.01f * x;
}

// Activation derivatives
static float pd_sigmoid(float y)
{
    return y * (1.0f - y);
}

static float pd_tanh(float y)
{
    return 1.0f - y * y;
}

static float pd_relu(float y)
{
    return y > 0.0f ? 1.0f : 0.0f;
}

static float pd_leaky_relu(float y)
{
    return y > 0.0f ? 1.0f : 0.01f;
}

static float activate(float x, MiyoActivation act)
{
    if(act == MIYO_ACT_SIGMOID) return act_sigmoid(x);
    if(act == MIYO_ACT_TANH) return act_tanh(x);
    if(act == MIYO_ACT_RELU) return act_relu(x);
    if(act == MIYO_ACT_LEAKY_RELU) return act_leaky_relu(x);
    return x;
}

static float pd_activate(float y, MiyoActivation act)
{
    if(act == MIYO_ACT_SIGMOID) return pd_sigmoid(y);
    if(act == MIYO_ACT_TANH) return pd_tanh(y);
    if(act == MIYO_ACT_RELU) return pd_relu(y);
    if(act == MIYO_ACT_LEAKY_RELU) return pd_leaky_relu(y);
    return 1.0f;
}

// Softmax
static void apply_softmax(float* output, int size)
{
    float max_val = output[0];
    for(int i = 1; i < size; i++)
        if(output[i] > max_val) max_val = output[i];
    
    float sum = 0.0f;
    for(int i = 0; i < size; i++)
    {
        output[i] = expf(output[i] - max_val);
        sum = sum + output[i];
    }
    for(int i = 0; i < size; i++)
        output[i] = output[i] / sum;
}

// Weight init
static void init_weights_random(float* w, int count)
{
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * 0.5f;
}

static void init_weights_xavier(float* w, int nin, int nout, int count)
{
    float limit = sqrtf(6.0f / (nin + nout));
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * limit;
}

static void init_weights_he(float* w, int nin, int count)
{
    float limit = sqrtf(6.0f / nin);
    for(int i = 0; i < count; i++)
        w[i] = frand_sym() * limit;
}

// Grad clip
static float clip_value(float val, float threshold)
{
    if(threshold <= 0.0f) return val;
    if(val > threshold) return threshold;
    if(val < -threshold) return -threshold;
    return val;
}

MiyoConfig miyo_config_default(void)
{
    MiyoConfig c;
    c.layer_sizes = NULL;
    c.num_layers = 0;
    c.layer_acts = NULL;
    c.learning_rate = 0.01f;
    c.optimizer = MIYO_OPT_SGD;
    c.momentum = 0.9f;
    c.rmsprop_decay = 0.9f;
    c.rmsprop_epsilon = 1e-8f;
    c.l2_lambda = 0.0f;
    c.dropout_rate = 0.0f;
    c.grad_clip = 0.0f;
    c.loss_type = MIYO_LOSS_MSE;
    c.init_type = MIYO_INIT_XAVIER;
    c.lr_schedule = MIYO_LR_CONSTANT;
    c.lr_decay_rate = 0.95f;
    c.lr_step_size = 10;
    c.total_epochs = 100;
    c.early_stop_patience = 0;
    c.early_stop_delta = 0.0001f;
    return c;
}

// Allocate layer
static MiyoLayer layer_alloc(int in_size, int out_size, MiyoActivation act,
                             MiyoWeightInit init, float dropout, MiyoOptimizer opt)
{
    MiyoLayer l;
    l.in_size = in_size;
    l.out_size = out_size;
    l.act = act;
    l.dropout_rate = dropout;
    
    int nw = out_size * in_size;
    
    l.weights = (float*)calloc(nw, sizeof(float));
    l.biases = (float*)calloc(out_size, sizeof(float));
    l.output = (float*)calloc(out_size, sizeof(float));
    l.output_pre_dropout = (float*)calloc(out_size, sizeof(float));
    l.pre_act = (float*)calloc(out_size, sizeof(float));
    l.delta = (float*)calloc(out_size, sizeof(float));
    l.grad_w = (float*)calloc(nw, sizeof(float));
    l.grad_b = (float*)calloc(out_size, sizeof(float));
    
    // Optimizer caches
    if(opt == MIYO_OPT_MOMENTUM || opt == MIYO_OPT_RMSPROP)
    {
        l.cache_w = (float*)calloc(nw, sizeof(float));
        l.cache_b = (float*)calloc(out_size, sizeof(float));
    }
    else
    {
        l.cache_w = NULL;
        l.cache_b = NULL;
    }
    
    // Dropout mask
    if(dropout > 0.0f)
        l.dropout_mask = (int*)malloc(out_size * sizeof(int));
    else
        l.dropout_mask = NULL;
    
    // Initialize weights
    if(init == MIYO_INIT_XAVIER)
        init_weights_xavier(l.weights, in_size, out_size, nw);
    else if(init == MIYO_INIT_HE)
        init_weights_he(l.weights, in_size, nw);
    else
        init_weights_random(l.weights, nw);
    
    return l;
}

// Free layer
static void layer_free(MiyoLayer* l)
{
    free(l->weights);
    free(l->biases);
    free(l->output);
    free(l->output_pre_dropout);
    free(l->pre_act);
    free(l->delta);
    free(l->grad_w);
    free(l->grad_b);
    if(l->cache_w) free(l->cache_w);
    if(l->cache_b) free(l->cache_b);
    if(l->dropout_mask) free(l->dropout_mask);
}

Miyo miyo_build(MiyoConfig cfg)
{
    Miyo m;
    m.nips = cfg.layer_sizes[0];
    m.nops = cfg.layer_sizes[cfg.num_layers - 1];
    m.num_layers = cfg.num_layers - 1;
    m.optimizer = cfg.optimizer;
    m.momentum = cfg.momentum;
    m.rmsprop_decay = cfg.rmsprop_decay;
    m.rmsprop_epsilon = cfg.rmsprop_epsilon;
    m.l2_lambda = cfg.l2_lambda;
    m.grad_clip = cfg.grad_clip;
    m.loss_type = cfg.loss_type;
    m.base_lr = cfg.learning_rate;
    m.training = 1;
    m.batch_count = 0;
    m.batch_loss = 0.0f;
    
    m.layers = (MiyoLayer*)malloc(m.num_layers * sizeof(MiyoLayer));
    
    for(int i = 0; i < m.num_layers; i++)
    {
        int in_size = cfg.layer_sizes[i];
        int out_size = cfg.layer_sizes[i + 1];
        int is_output = (i == m.num_layers - 1);
        
        MiyoActivation act;
        if(cfg.layer_acts != NULL)
            act = cfg.layer_acts[i];
        else
        {
            if(is_output)
                act = (cfg.loss_type == MIYO_LOSS_CROSS_ENTROPY) ? MIYO_ACT_SOFTMAX : MIYO_ACT_SIGMOID;
            else
                act = MIYO_ACT_RELU;
        }
        
        float dropout = is_output ? 0.0f : cfg.dropout_rate;
        
        m.layers[i] = layer_alloc(in_size, out_size, act, cfg.init_type,
                                  dropout, cfg.optimizer);
    }
    
    // Early stopping
    if(cfg.early_stop_patience > 0)
    {
        m.early_stop = (MiyoEarlyStopping*)malloc(sizeof(MiyoEarlyStopping));
        m.early_stop->best_error = 1e9f;
        m.early_stop->patience = cfg.early_stop_patience;
        m.early_stop->wait_count = 0;
        m.early_stop->enabled = 1;
        m.early_stop->min_delta = cfg.early_stop_delta;
    }
    else
        m.early_stop = NULL;
    
    // Learning rate scheduler
    if(cfg.lr_schedule != MIYO_LR_CONSTANT)
    {
        m.lr_sched = (MiyoLRScheduler*)malloc(sizeof(MiyoLRScheduler));
        m.lr_sched->type = cfg.lr_schedule;
        m.lr_sched->initial_lr = cfg.learning_rate;
        m.lr_sched->current_lr = cfg.learning_rate;
        m.lr_sched->step_size = cfg.lr_step_size;
        m.lr_sched->decay_rate = cfg.lr_decay_rate;
        m.lr_sched->total_epochs = cfg.total_epochs;
        m.lr_sched->current_epoch = 0;
    }
    else
        m.lr_sched = NULL;
    
    return m;
}

void miyo_free(Miyo m)
{
    for(int i = 0; i < m.num_layers; i++)
        layer_free(&m.layers[i]);
    free(m.layers);
    if(m.early_stop) free(m.early_stop);
    if(m.lr_sched) free(m.lr_sched);
}

// Dropout forward
static void dropout_forward(MiyoLayer* l, int training)
{
    for(int i = 0; i < l->out_size; i++)
        l->output_pre_dropout[i] = l->output[i];
    
    if(l->dropout_rate <= 0.0f || l->dropout_mask == NULL) return;
    
    if(training)
    {
        float scale = 1.0f / (1.0f - l->dropout_rate);
        for(int i = 0; i < l->out_size; i++)
        {
            l->dropout_mask[i] = (frand() > l->dropout_rate) ? 1 : 0;
            l->output[i] = l->dropout_mask[i] ? l->output[i] * scale : 0.0f;
        }
    }
}

// Layer forward
static void layer_forward(MiyoLayer* l, const float* input, int training)
{
    for(int i = 0; i < l->out_size; i++)
    {
        float sum = l->biases[i];
        for(int j = 0; j < l->in_size; j++)
            sum = sum + input[j] * l->weights[i * l->in_size + j];
        l->pre_act[i] = sum;
    }
    
    if(l->act == MIYO_ACT_SOFTMAX)
    {
        for(int i = 0; i < l->out_size; i++)
            l->output[i] = l->pre_act[i];
        apply_softmax(l->output, l->out_size);
    }
    else
    {
        for(int i = 0; i < l->out_size; i++)
            l->output[i] = activate(l->pre_act[i], l->act);
    }
    
    dropout_forward(l, training);
}

float* miyo_predict(Miyo* m, const float* input)
{
    const float* layer_input = input;
    
    for(int i = 0; i < m->num_layers; i++)
    {
        layer_forward(&m->layers[i], layer_input, m->training);
        layer_input = m->layers[i].output;
    }
    
    return m->layers[m->num_layers - 1].output;
}

// Loss
static float compute_loss(Miyo* m, const float* target)
{
    MiyoLayer* out = &m->layers[m->num_layers - 1];
    float loss = 0.0f;
    
    if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY)
    {
        if(out->act == MIYO_ACT_SOFTMAX)
        {
            // Categorical CE: -sum(t * log(p))
            for(int i = 0; i < out->out_size; i++)
            {
                float p = out->output[i];
                if(p < 1e-7f) p = 1e-7f;
                loss = loss - target[i] * logf(p);
            }
        }
        else if(out->act == MIYO_ACT_SIGMOID)
        {
            // Binary CE: -sum(t*log(p) + (1-t)*log(1-p))
            for(int i = 0; i < out->out_size; i++)
            {
                float y = out->output[i];
                float t = target[i];
                if(y < 1e-7f) y = 1e-7f;
                if(y > 1.0f - 1e-7f) y = 1.0f - 1e-7f;
                loss = loss - (t * logf(y) + (1.0f - t) * logf(1.0f - y));
            }
        }
        else
        {
            // Fallback to MSE for other activations
            for(int i = 0; i < out->out_size; i++)
            {
                float diff = target[i] - out->output[i];
                loss = loss + 0.5f * diff * diff;
            }
        }
    }
    else
    {
        for(int i = 0; i < out->out_size; i++)
        {
            float diff = target[i] - out->output[i];
            loss = loss + 0.5f * diff * diff;
        }
    }
    
    // L2 regularization
    if(m->l2_lambda > 0.0f)
    {
        float l2_sum = 0.0f;
        for(int l = 0; l < m->num_layers; l++)
        {
            int nw = m->layers[l].in_size * m->layers[l].out_size;
            for(int i = 0; i < nw; i++)
                l2_sum = l2_sum + m->layers[l].weights[i] * m->layers[l].weights[i];
        }
        loss = loss + 0.5f * m->l2_lambda * l2_sum;
    }
    
    return loss;
}

// Output delta
static void compute_output_delta(Miyo* m, const float* target)
{
    MiyoLayer* out = &m->layers[m->num_layers - 1];
    
    if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY && out->act == MIYO_ACT_SOFTMAX)
    {
        // Softmax + CE: delta = y - t
        for(int i = 0; i < out->out_size; i++)
            out->delta[i] = out->output[i] - target[i];
    }
    else if(m->loss_type == MIYO_LOSS_CROSS_ENTROPY && out->act == MIYO_ACT_SIGMOID)
    {
        // Sigmoid + BCE: delta = y - t (simplified form)
        for(int i = 0; i < out->out_size; i++)
            out->delta[i] = out->output[i] - target[i];
    }
    else
    {
        // MSE or CE fallback: dL/dy = (y - t) * f'(pre_act)
        for(int i = 0; i < out->out_size; i++)
        {
            float err = out->output[i] - target[i];
            out->delta[i] = err * pd_activate(out->output_pre_dropout[i], out->act);
        }
    }
}

// Backprop
static void backward(Miyo* m, const float* input)
{
    // Propagate deltas backward through hidden layers
    for(int l = m->num_layers - 2; l >= 0; l--)
    {
        MiyoLayer* curr = &m->layers[l];
        MiyoLayer* next = &m->layers[l + 1];
        
        for(int i = 0; i < curr->out_size; i++)
        {
            // Sum weighted gradients from next layer
            float sum = 0.0f;
            for(int j = 0; j < next->out_size; j++)
                sum = sum + next->delta[j] * next->weights[j * next->in_size + i];
            
            // Apply dropout backward (inverted dropout scaling)
            if(curr->dropout_mask && m->training)
            {
                if(!curr->dropout_mask[i])
                {
                    curr->delta[i] = 0.0f;
                    continue;
                }
                sum = sum / (1.0f - curr->dropout_rate);
            }
            
            // Activation derivative (use pre-dropout output)
            float act_grad = pd_activate(curr->output_pre_dropout[i], curr->act);
            curr->delta[i] = sum * act_grad;
        }
    }
    
    // Compute weight and bias gradients
    for(int l = 0; l < m->num_layers; l++)
    {
        MiyoLayer* layer = &m->layers[l];
        const float* layer_input = (l == 0) ? input : m->layers[l - 1].output;
        
        for(int i = 0; i < layer->out_size; i++)
        {
            // Weight gradients
            for(int j = 0; j < layer->in_size; j++)
            {
                float grad = layer->delta[i] * layer_input[j];
                
                // L2 regularization gradient
                if(m->l2_lambda > 0.0f)
                    grad = grad + m->l2_lambda * layer->weights[i * layer->in_size + j];
                
                grad = clip_value(grad, m->grad_clip);
                layer->grad_w[i * layer->in_size + j] = layer->grad_w[i * layer->in_size + j] + grad;
            }
            
            // Bias gradient
            float bias_grad = clip_value(layer->delta[i], m->grad_clip);
            layer->grad_b[i] = layer->grad_b[i] + bias_grad;
        }
    }
}

// Apply gradients with optimizer
static void apply_gradients(Miyo* m, float lr, int batch_size)
{
    float scale = 1.0f / batch_size;

    for(int l = 0; l < m->num_layers; l++)
    {
        MiyoLayer* layer = &m->layers[l];
        int nw = layer->in_size * layer->out_size;

        if(m->optimizer == MIYO_OPT_SGD)
        {
            for(int i = 0; i < nw; i++)
                layer->weights[i] = layer->weights[i] - lr * layer->grad_w[i] * scale;
            for(int i = 0; i < layer->out_size; i++)
                layer->biases[i] = layer->biases[i] - lr * layer->grad_b[i] * scale;
        }
        else if(m->optimizer == MIYO_OPT_MOMENTUM)
        {
            for(int i = 0; i < nw; i++)
            {
                layer->cache_w[i] = m->momentum * layer->cache_w[i] + layer->grad_w[i] * scale;
                layer->weights[i] = layer->weights[i] - lr * layer->cache_w[i];
            }
            for(int i = 0; i < layer->out_size; i++)
            {
                layer->cache_b[i] = m->momentum * layer->cache_b[i] + layer->grad_b[i] * scale;
                layer->biases[i] = layer->biases[i] - lr * layer->cache_b[i];
            }
        }
        else if(m->optimizer == MIYO_OPT_RMSPROP)
        {
            float decay = m->rmsprop_decay;
            float eps = (m->rmsprop_epsilon > 0.0f) ? m->rmsprop_epsilon : 1e-8f;

            for(int i = 0; i < nw; i++)
            {
                float g = layer->grad_w[i] * scale;
                layer->cache_w[i] = decay * layer->cache_w[i] + (1.0f - decay) * g * g;
                layer->weights[i] = layer->weights[i] - lr * g / (sqrtf(layer->cache_w[i]) + eps);
            }
            for(int i = 0; i < layer->out_size; i++)
            {
                float g = layer->grad_b[i] * scale;
                layer->cache_b[i] = decay * layer->cache_b[i] + (1.0f - decay) * g * g;
                layer->biases[i] = layer->biases[i] - lr * g / (sqrtf(layer->cache_b[i]) + eps);
            }
        }

        // Clear gradients
        for(int i = 0; i < nw; i++) layer->grad_w[i] = 0.0f;
        for(int i = 0; i < layer->out_size; i++) layer->grad_b[i] = 0.0f;
    }
}

float miyo_train(Miyo* m, const float* input, const float* target, float lr)
{
    miyo_predict(m, input);
    float loss = compute_loss(m, target);
    compute_output_delta(m, target);
    backward(m, input);
    apply_gradients(m, lr, 1);
    return loss;
}

void miyo_batch_accumulate(Miyo* m, const float* input, const float* target)
{
    miyo_predict(m, input);
    m->batch_loss = m->batch_loss + compute_loss(m, target);
    compute_output_delta(m, target);
    backward(m, input);
    m->batch_count++;
}

float miyo_batch_update(Miyo* m, float lr)
{
    if(m->batch_count == 0) return 0.0f;
    
    apply_gradients(m, lr, m->batch_count);
    float avg_loss = m->batch_loss / m->batch_count;
    
    m->batch_count = 0;
    m->batch_loss = 0.0f;
    
    return avg_loss;
}

void miyo_epoch_start(Miyo* m)
{
    if(m->lr_sched == NULL) return;
    
    MiyoLRScheduler* s = m->lr_sched;
    int epoch = s->current_epoch;
    
    if(s->type == MIYO_LR_STEP_DECAY)
    {
        if(s->step_size <= 0) { s->current_lr = s->initial_lr; return; }
        int steps = epoch / s->step_size;
        s->current_lr = s->initial_lr * powf(s->decay_rate, (float)steps);
    }
    else if(s->type == MIYO_LR_EXPONENTIAL)
    {
        s->current_lr = s->initial_lr * powf(s->decay_rate, (float)epoch);
    }
    else if(s->type == MIYO_LR_COSINE)
    {
        if(s->total_epochs <= 0) { s->current_lr = s->initial_lr; return; }
        float pi = 3.14159265359f;
        float progress = (float)epoch / (float)s->total_epochs;
        if(progress > 1.0f) progress = 1.0f;
        s->current_lr = s->initial_lr * 0.5f * (1.0f + cosf(pi * progress));
    }
}

void miyo_epoch_end(Miyo* m)
{
    if(m->lr_sched)
        m->lr_sched->current_epoch++;
}

float miyo_get_lr(Miyo* m)
{
    if(m->lr_sched)
        return m->lr_sched->current_lr;
    return m->base_lr;
}

int miyo_early_stop_check(Miyo* m, float error)
{
    if(m->early_stop == NULL || !m->early_stop->enabled) return 0;
    
    MiyoEarlyStopping* es = m->early_stop;
    
    if(error < es->best_error - es->min_delta)
    {
        es->best_error = error;
        es->wait_count = 0;
        return 0;
    }
    
    es->wait_count++;
    if(es->wait_count >= es->patience) return 1;
    return 0;
}

void miyo_set_training(Miyo* m, int training)
{
    m->training = training;
}

// Save network
void miyo_save(Miyo m, const char* path)
{
    FILE* f = fopen(path, "w");
    if(f == NULL) return;

    // Header
    fprintf(f, "%d\n", m.num_layers + 1);
    fprintf(f, "%d ", m.nips);
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%d ", m.layers[i].out_size);
    fprintf(f, "\n");

    // Activations
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%d ", m.layers[i].act);
    fprintf(f, "\n");

    // Dropout rates
    for(int i = 0; i < m.num_layers; i++)
        fprintf(f, "%.9g ", (double)m.layers[i].dropout_rate);
    fprintf(f, "\n");

    // Network config (more precision to keep tiny epsilons)
    fprintf(f, "%d %.9g %.9g %.9g %.9g %.9g %d\n",
            m.optimizer, (double)m.momentum, (double)m.rmsprop_decay,
            (double)m.rmsprop_epsilon, (double)m.l2_lambda,
            (double)m.grad_clip, m.loss_type);
    fprintf(f, "%.9g\n", (double)m.base_lr);

    // LR scheduler state
    int has_lr_sched = (m.lr_sched != NULL) ? 1 : 0;
    fprintf(f, "%d\n", has_lr_sched);
    if(has_lr_sched)
    {
        fprintf(f, "%d %.9g %.9g %d %.9g %d %d\n",
                m.lr_sched->type, (double)m.lr_sched->initial_lr,
                (double)m.lr_sched->current_lr, m.lr_sched->step_size,
                (double)m.lr_sched->decay_rate, m.lr_sched->total_epochs,
                m.lr_sched->current_epoch);
    }

    // Early stopping state
    int has_early_stop = (m.early_stop != NULL) ? 1 : 0;
    fprintf(f, "%d\n", has_early_stop);
    if(has_early_stop)
    {
        fprintf(f, "%.9g %d %d %d %.9g\n",
                (double)m.early_stop->best_error, m.early_stop->patience,
                m.early_stop->wait_count, m.early_stop->enabled,
                (double)m.early_stop->min_delta);
    }

    // Weights and biases
    for(int l = 0; l < m.num_layers; l++)
    {
        MiyoLayer* layer = &m.layers[l];
        int nw = layer->in_size * layer->out_size;

        for(int i = 0; i < nw; i++)
            fprintf(f, "%.9g\n", (double)layer->weights[i]);
        for(int i = 0; i < layer->out_size; i++)
            fprintf(f, "%.9g\n", (double)layer->biases[i]);
    }

    // Optimizer caches
    if(m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP)
    {
        for(int l = 0; l < m.num_layers; l++)
        {
            MiyoLayer* layer = &m.layers[l];
            int nw = layer->in_size * layer->out_size;

            for(int i = 0; i < nw; i++)
                fprintf(f, "%.9g\n", (double)layer->cache_w[i]);
            for(int i = 0; i < layer->out_size; i++)
                fprintf(f, "%.9g\n", (double)layer->cache_b[i]);
        }
    }

    fclose(f);
}

// Load network
Miyo miyo_load(const char* path)
{
    Miyo m;
    memset(&m, 0, sizeof(Miyo));

    FILE* f = fopen(path, "r");
    if(f == NULL)
    {
        fprintf(stderr, "Error: Could not open file '%s'\n", path);
        return m;
    }

    int total_layers;
    if(fscanf(f, "%d\n", &total_layers) != 1 || total_layers < 2)
    {
        fprintf(stderr, "Error: Invalid file format in '%s'\n", path);
        fclose(f);
        return m;
    }

    int* sizes = (int*)malloc(total_layers * sizeof(int));
    for(int i = 0; i < total_layers; i++)
    {
        if(fscanf(f, "%d ", &sizes[i]) != 1)
        {
            fprintf(stderr, "Error: Failed to read layer sizes\n");
            free(sizes);
            fclose(f);
            return m;
        }
    }

    MiyoActivation* acts = (MiyoActivation*)malloc((total_layers - 1) * sizeof(MiyoActivation));
    for(int i = 0; i < total_layers - 1; i++)
    {
        int a;
        if(fscanf(f, "%d ", &a) != 1)
        {
            fprintf(stderr, "Error: Failed to read activations\n");
            free(sizes);
            free(acts);
            fclose(f);
            return m;
        }
        acts[i] = (MiyoActivation)a;
    }

    // Dropout rates
    float* dropouts = (float*)malloc((total_layers - 1) * sizeof(float));
    for(int i = 0; i < total_layers - 1; i++)
    {
        if(fscanf(f, "%f ", &dropouts[i]) != 1)
        {
            fprintf(stderr, "Error: Failed to read dropout rates\n");
            free(sizes);
            free(acts);
            free(dropouts);
            fclose(f);
            return m;
        }
    }

    // Network config
    int optimizer_int, loss_int;
    float momentum, rmsprop_decay, rmsprop_epsilon, l2_lambda, grad_clip, base_lr;
    if(fscanf(f, "%d %f %f %f %f %f %d\n",
              &optimizer_int, &momentum, &rmsprop_decay,
              &rmsprop_epsilon, &l2_lambda, &grad_clip, &loss_int) != 7)
    {
        fprintf(stderr, "Error: Failed to read network config\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }
    if(fscanf(f, "%f\n", &base_lr) != 1)
    {
        fprintf(stderr, "Error: Failed to read base_lr\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }

    // Ensure epsilon is usable (avoid 0 -> NaN in RMSProp)
    if(rmsprop_epsilon <= 0.0f) rmsprop_epsilon = 1e-8f;

    // LR scheduler
    int has_lr_sched;
    MiyoLRScheduler* lr_sched = NULL;
    if(fscanf(f, "%d\n", &has_lr_sched) != 1)
    {
        fprintf(stderr, "Error: Failed to read lr_sched flag\n");
        free(sizes);
        free(acts);
        free(dropouts);
        fclose(f);
        return m;
    }
    if(has_lr_sched)
    {
        lr_sched = (MiyoLRScheduler*)malloc(sizeof(MiyoLRScheduler));
        int sched_type;
        if(fscanf(f, "%d %f %f %d %f %d %d\n",
                  &sched_type, &lr_sched->initial_lr, &lr_sched->current_lr,
                  &lr_sched->step_size, &lr_sched->decay_rate,
                  &lr_sched->total_epochs, &lr_sched->current_epoch) != 7)
        {
            fprintf(stderr, "Error: Failed to read lr_sched\n");
            free(sizes);
            free(acts);
            free(dropouts);
            free(lr_sched);
            fclose(f);
            return m;
        }
        lr_sched->type = (MiyoLRSchedule)sched_type;
    }

    // Early stopping
    int has_early_stop;
    MiyoEarlyStopping* early_stop = NULL;
    if(fscanf(f, "%d\n", &has_early_stop) != 1)
    {
        fprintf(stderr, "Error: Failed to read early_stop flag\n");
        free(sizes);
        free(acts);
        free(dropouts);
        if(lr_sched) free(lr_sched);
        fclose(f);
        return m;
    }
    if(has_early_stop)
    {
        early_stop = (MiyoEarlyStopping*)malloc(sizeof(MiyoEarlyStopping));
        if(fscanf(f, "%f %d %d %d %f\n",
                  &early_stop->best_error, &early_stop->patience,
                  &early_stop->wait_count, &early_stop->enabled,
                  &early_stop->min_delta) != 5)
        {
            fprintf(stderr, "Error: Failed to read early_stop\n");
            free(sizes);
            free(acts);
            free(dropouts);
            if(lr_sched) free(lr_sched);
            free(early_stop);
            fclose(f);
            return m;
        }
    }

    // Build network manually to preserve loaded config
    m.nips = sizes[0];
    m.nops = sizes[total_layers - 1];
    m.num_layers = total_layers - 1;
    m.optimizer = (MiyoOptimizer)optimizer_int;
    m.momentum = momentum;
    m.rmsprop_decay = rmsprop_decay;
    m.rmsprop_epsilon = rmsprop_epsilon;
    m.l2_lambda = l2_lambda;
    m.grad_clip = grad_clip;
    m.loss_type = (MiyoLoss)loss_int;
    m.base_lr = base_lr;
    m.training = 0;
    m.batch_count = 0;
    m.batch_loss = 0.0f;
    m.lr_sched = lr_sched;
    m.early_stop = early_stop;

    // Allocate layers
    m.layers = (MiyoLayer*)malloc(m.num_layers * sizeof(MiyoLayer));
    for(int i = 0; i < m.num_layers; i++)
    {
        MiyoLayer* l = &m.layers[i];
        l->in_size = sizes[i];
        l->out_size = sizes[i + 1];
        l->act = acts[i];
        l->dropout_rate = dropouts[i];

        int nw = l->out_size * l->in_size;
        l->weights = (float*)calloc(nw, sizeof(float));
        l->biases = (float*)calloc(l->out_size, sizeof(float));
        l->output = (float*)calloc(l->out_size, sizeof(float));
        l->output_pre_dropout = (float*)calloc(l->out_size, sizeof(float));
        l->pre_act = (float*)calloc(l->out_size, sizeof(float));
        l->delta = (float*)calloc(l->out_size, sizeof(float));
        l->grad_w = (float*)calloc(nw, sizeof(float));
        l->grad_b = (float*)calloc(l->out_size, sizeof(float));

        if(m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP)
        {
            l->cache_w = (float*)calloc(nw, sizeof(float));
            l->cache_b = (float*)calloc(l->out_size, sizeof(float));
        }
        else
        {
            l->cache_w = NULL;
            l->cache_b = NULL;
        }

        if(l->dropout_rate > 0.0f)
            l->dropout_mask = (int*)malloc(l->out_size * sizeof(int));
        else
            l->dropout_mask = NULL;
    }

    // Load weights and biases
    int load_ok = 1;
    for(int l = 0; l < m.num_layers && load_ok; l++)
    {
        MiyoLayer* layer = &m.layers[l];
        int nw = layer->in_size * layer->out_size;

        for(int i = 0; i < nw && load_ok; i++)
        {
            if(fscanf(f, "%f\n", &layer->weights[i]) != 1)
            {
                fprintf(stderr, "Error: Failed to read weight %d in layer %d\n", i, l);
                load_ok = 0;
            }
        }
        for(int i = 0; i < layer->out_size && load_ok; i++)
        {
            if(fscanf(f, "%f\n", &layer->biases[i]) != 1)
            {
                fprintf(stderr, "Error: Failed to read bias %d in layer %d\n", i, l);
                load_ok = 0;
            }
        }
    }

    // Load optimizer caches
    if(load_ok && (m.optimizer == MIYO_OPT_MOMENTUM || m.optimizer == MIYO_OPT_RMSPROP))
    {
        for(int l = 0; l < m.num_layers && load_ok; l++)
        {
            MiyoLayer* layer = &m.layers[l];
            int nw = layer->in_size * layer->out_size;

            for(int i = 0; i < nw && load_ok; i++)
            {
                if(fscanf(f, "%f\n", &layer->cache_w[i]) != 1)
                {
                    fprintf(stderr, "Error: Failed to read cache_w %d in layer %d\n", i, l);
                    load_ok = 0;
                }
            }
            for(int i = 0; i < layer->out_size && load_ok; i++)
            {
                if(fscanf(f, "%f\n", &layer->cache_b[i]) != 1)
                {
                    fprintf(stderr, "Error: Failed to read cache_b %d in layer %d\n", i, l);
                    load_ok = 0;
                }
            }
        }
    }

    free(sizes);
    free(acts);
    free(dropouts);
    fclose(f);

    if(!load_ok)
    {
        miyo_free(m);
        memset(&m, 0, sizeof(Miyo));
    }

    return m;
}

void miyo_print(const float* arr, int size)
{
    for(int i = 0; i < size; i++)
        printf("%f ", (double)arr[i]);
    printf("\n");
}
